"""VOID // SENTINEL — Dashboard Bridge API (Port 8001).

Translates VOID's authoritative SecurityEvent database schema into the exact UI data shape
expected by Person 2's React Dashboard (void.js).

Features:
- CORS enabled for all origins (*)
- Field mapping:
    event_id    -> id
    source_ip   -> client_ip
    path        -> endpoint
    evidence    -> payload (joined string)
    attack_type -> human-friendly label
    severity    -> CRITICAL | HIGH | INFO (MEDIUM -> HIGH, LOW/NONE -> INFO)
    action      -> action_taken label
    geo         -> geo tag or 'UNKNOWN'
- Endpoints:
    GET  /api/events     — Returns transformed events for dashboard telemetry feed
    GET  /api/stats      — Returns KPI metrics: total_events, decoy_hits, unique_attacker_ips, blocklist_size
    POST /api/blacklist  — Blacklist an adversary IP
    GET  /api/blacklist  — List currently quarantined IPs
    DELETE /api/blacklist/{ip} — Remove an IP from quarantine
    GET  /health         — Health status check
"""

import logging
import os
from typing import Any, Dict, List, Optional
from fastapi import FastAPI, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from persistence.db_adapter import EventPersistence

logger = logging.getLogger("void.bridge_api")

app = FastAPI(
    title="VOID // SENTINEL — Dashboard Bridge API",
    description="Bridge connecting persistent security events with Person 2's React dashboard.",
    version="1.0.0",
)

# Enable CORS for Person 2's dashboard (served on port 8080 or 3000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Shared persistence instance
db = EventPersistence()

# Mapping specifications
ATTACK_TYPE_LABELS = {
    "DECOY_ACCESS": "Decoy Route Access",
    "SQL_INJECTION": "SQL Injection Probe",
    "PATH_TRAVERSAL": "Directory Traversal",
    "COMMAND_INJECTION": "RCE Payload Injection",
    "REQUEST_BURST": "Request Burst Anomaly",
    "RECONNAISSANCE": "Admin Panel Recon",
    "SUSPICIOUS_REQUEST": "Suspicious Request Pattern",
    "NONE": "Normal Traffic",
}

ACTION_LABELS = {
    "SYNTHETIC_RESPONSE": "Decoy Served & IP Logged",
    "REQUEST_TEMPORARY_BLOCK": "Canary Token Fired • IP Blacklisted",
    "RATE_LIMIT": "Throttle Applied • Flagged",
    "REQUIRE_ANALYST_REVIEW": "Rate-Limited • Logged for Review",
    "ALLOW": "Passthrough Logged",
    "LOG_ONLY": "Clean — Telemetry Recorded",
}


def map_severity_to_dashboard(sev: str) -> str:
    """Map VOID severities to Person 2's 3-tier severity schema: CRITICAL, HIGH, INFO."""
    normalized = str(sev).upper()
    if normalized == "CRITICAL":
        return "CRITICAL"
    if normalized in ("HIGH", "MEDIUM"):
        return "HIGH"
    # LOW, NONE or unknown map to INFO
    return "INFO"


def map_event_to_dashboard(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Map stored SecurityEvent row into Person 2's React Dashboard schema."""
    # Build payload string from evidence or request details
    evidence = raw.get("evidence", [])
    if isinstance(evidence, list) and len(evidence) > 0:
        payload_str = "\n".join(str(e) for e in evidence)
    else:
        payload_str = f"{raw.get('method', 'GET')} {raw.get('path', '/')}\nReason: {raw.get('reason', '')}"

    raw_attack = str(raw.get("attack_type", "NONE"))
    attack_label = ATTACK_TYPE_LABELS.get(raw_attack, raw_attack.replace("_", " ").title())

    raw_action = str(raw.get("action", "ALLOW"))
    action_label = ACTION_LABELS.get(raw_action, raw_action.replace("_", " ").title())

    # Detect local/private IP for basic geo annotation
    client_ip = str(raw.get("source_ip", "UNKNOWN"))
    geo = "UNKNOWN"
    if client_ip in ("127.0.0.1", "::1", "localhost"):
        geo = "LOCAL"
    elif client_ip.startswith(("10.", "192.168.", "172.16.")):
        geo = "INTERNAL"

    return {
        "id": raw.get("event_id", ""),
        "timestamp": raw.get("timestamp", ""),
        "client_ip": client_ip,
        "attack_type": attack_label,
        "endpoint": raw.get("path", "/"),
        "payload": payload_str,
        "severity": map_severity_to_dashboard(str(raw.get("severity", "LOW"))),
        "action_taken": action_label,
        "geo": geo,
        "decoy_triggered": bool(raw.get("decoy_triggered", False)),
        "risk_score": int(raw.get("risk_score", 0)),
    }


class BlacklistRequest(BaseModel):
    ip: str = Field(..., description="Adversary IP to blacklist")
    reason: Optional[str] = Field("Manually blacklisted via Dashboard Bridge", description="Reason for ban")


@app.get("/health", tags=["System"])
async def health_check() -> Dict[str, Any]:
    """Health check endpoint for Dashboard Bridge."""
    return {
        "status": "healthy",
        "service": "VOID Dashboard Bridge",
        "port": 8001,
        "database_connected": True,
        "event_count": db.get_event_count(),
    }


@app.get("/api/events", tags=["Dashboard"])
async def get_dashboard_events(
    limit: int = Query(50, ge=1, le=500, description="Max events to return"),
    severity: Optional[str] = Query(None, description="Filter by severity: CRITICAL, HIGH, INFO"),
    decoy_only: Optional[bool] = Query(None, description="Filter only decoy canary events"),
    client_ip: Optional[str] = Query(None, description="Filter by client IP"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
) -> List[Dict[str, Any]]:
    """Retrieve security events formatted for Person 2's React dashboard feed."""
    # If the user queried with dashboard severity 'HIGH', in backend that corresponds to HIGH or MEDIUM
    db_severity = None
    if severity:
        sev_upper = severity.upper()
        if sev_upper == "CRITICAL":
            db_severity = "CRITICAL"
        elif sev_upper in ("INFO", "CLEAN"):
            db_severity = "LOW"

    raw_events = db.query_events(
        limit=limit,
        severity=db_severity,
        decoy_only=decoy_only,
        source_ip=client_ip,
        offset=offset,
    )

    transformed = [map_event_to_dashboard(ev) for ev in raw_events]

    # Post-filter if dashboard requested HIGH (which covers both HIGH and MEDIUM)
    if severity and severity.upper() in ("HIGH", "WARNING"):
        transformed = [ev for ev in transformed if ev["severity"] == "HIGH"]

    return transformed


@app.get("/api/stats", tags=["Dashboard"])
async def get_dashboard_stats() -> Dict[str, Any]:
    """Return KPI metrics matching the dashboard cards."""
    stats = db.get_stats()
    return {
        "total_events": stats["total"],
        "decoy_hits": stats["decoy_hits"],
        "unique_attacker_ips": stats["unique_ips"],
        "blocklist_size": stats["blocklist_size"],
        "aggregate_risk_score": stats["aggregate_system_risk"],
        "severity_counts": stats["by_severity"],
        "attack_type_counts": stats["by_attack_type"],
        "top_ips": stats["top_ips"],
    }


@app.post("/api/blacklist", tags=["Defensive Control"])
async def blacklist_ip(req: BlacklistRequest) -> Dict[str, Any]:
    """Add an adversary IP to the quarantine blacklist."""
    clean_ip = req.ip.strip()
    if not clean_ip:
        raise HTTPException(status_code=400, detail="IP address cannot be empty")

    success = db.add_blacklisted_ip(clean_ip, reason=req.reason or "")
    if not success:
        raise HTTPException(status_code=500, detail="Failed to add IP to blacklist")

    stats = db.get_stats()
    return {
        "status": "blacklisted",
        "ip": clean_ip,
        "blocklist_size": stats["blocklist_size"],
        "message": f"IP {clean_ip} quarantined successfully",
    }


@app.get("/api/blacklist", tags=["Defensive Control"])
async def list_blacklisted_ips() -> List[Dict[str, Any]]:
    """List all currently quarantined adversary IPs."""
    return db.get_blacklisted_ips()


@app.delete("/api/blacklist/{ip}", tags=["Defensive Control"])
async def remove_blacklisted_ip(ip: str) -> Dict[str, Any]:
    """Remove an IP from the quarantine blacklist."""
    removed = db.remove_blacklisted_ip(ip)
    stats = db.get_stats()
    return {
        "status": "removed" if removed else "not_found",
        "ip": ip,
        "blocklist_size": stats["blocklist_size"],
    }


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("BRIDGE_PORT", 8001))
    print(f"\n[VOID // SENTINEL] Dashboard Bridge API running on http://127.0.0.1:{port}")
    uvicorn.run("bridge_api:app", host="127.0.0.1", port=port, reload=False)
