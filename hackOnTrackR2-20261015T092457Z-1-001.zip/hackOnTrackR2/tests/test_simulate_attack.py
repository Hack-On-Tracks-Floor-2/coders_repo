"""Unit tests for simulate_attack (safety checks, modes, CLI parsing)."""

from unittest.mock import MagicMock, patch
import pytest

from simulate_attack import AttackSimulator, is_safe_target


def test_is_safe_target_logic():
    """Verify safety guard correctly permits internal IPs and rejects external public addresses."""
    # Permitted targets
    assert is_safe_target("http://localhost:8000") is True
    assert is_safe_target("http://127.0.0.1:8000") is True
    assert is_safe_target("http://127.0.0.1") is True
    assert is_safe_target("http://10.0.0.5:8000") is True
    assert is_safe_target("http://192.168.1.1:8080") is True
    assert is_safe_target("http://172.16.0.1:8000") is True

    # External targets blocked by default
    assert is_safe_target("https://google.com") is False
    assert is_safe_target("http://8.8.8.8") is False
    assert is_safe_target("https://api.external.com") is False


def test_simulator_healthcheck_success():
    """Test healthcheck returning True when backend returns HTTP 200."""
    sim = AttackSimulator(target="http://127.0.0.1:8000", quiet=True)
    with patch.object(sim, "send_request", return_value={"status": 200, "duration_ms": 1.5}):
        assert sim.run_healthcheck() is True


def test_simulator_healthcheck_failure():
    """Test healthcheck returning False when backend is unreachable."""
    sim = AttackSimulator(target="http://127.0.0.1:8000", quiet=True)
    with patch.object(sim, "send_request", return_value={"status": 0, "error": "Connection refused"}):
        assert sim.run_healthcheck() is False


def test_simulator_metrics_tracking():
    """Verify simulator properly increments metrics counters."""
    sim = AttackSimulator(target="http://127.0.0.1:8000", delay=0.0, quiet=True)

    # Mock response object for requests
    mock_resp_normal = MagicMock()
    mock_resp_normal.status_code = 200
    mock_resp_normal.headers = {}
    mock_resp_normal.text = "OK"
    mock_resp_normal.url = "http://127.0.0.1:8000/normal"

    mock_resp_decoy = MagicMock()
    mock_resp_decoy.status_code = 200
    mock_resp_decoy.headers = {"x-void-interception": "DECOY_TRIGGERED"}
    mock_resp_decoy.text = "DECOY"
    mock_resp_decoy.url = "http://127.0.0.1:8000/admin/backup.sql"

    mock_resp_blocked = MagicMock()
    mock_resp_blocked.status_code = 429
    mock_resp_blocked.headers = {}
    mock_resp_blocked.text = "RATE_LIMITED"
    mock_resp_blocked.url = "http://127.0.0.1:8000/burst"

    if sim.session:
        with patch.object(
            sim.session,
            "request",
            side_effect=[mock_resp_normal, mock_resp_decoy, mock_resp_blocked],
        ):
            r1 = sim.send_request("/normal")
            r2 = sim.send_request("/admin/backup.sql")
            r3 = sim.send_request("/burst")

            assert sim.metrics["requests_sent"] == 3
            assert sim.metrics["successful_200"] == 2
            assert sim.metrics["decoys_triggered"] == 1
            assert sim.metrics["blocked_or_throttled"] == 1
            assert r1["status"] == 200
            assert r2["is_decoy"] is True
            assert r3["is_blocked"] is True
    else:
        # Fallback test if requests is not installed
        assert sim.metrics["requests_sent"] == 0

