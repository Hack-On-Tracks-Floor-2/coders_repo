"""Unit and integration tests for Dashboard Bridge API (FastAPI port 8001)."""

import pytest
from fastapi.testclient import TestClient

from bridge_api import app, map_severity_to_dashboard, map_event_to_dashboard
from schemas import AttackType, SecurityAction, SecurityEvent, SeverityLevel
from persistence.db_adapter import EventPersistence


@pytest.fixture
def client(test_persister: EventPersistence, monkeypatch) -> TestClient:
    """FastAPI TestClient with isolated temporary database."""
    # Patch the global db instance in bridge_api with test_persister
    monkeypatch.setattr("bridge_api.db", test_persister)
    return TestClient(app)


def test_severity_mapping_logic():
    """Verify severity mapping from 4 levels to Dashboard's 3 levels."""
    assert map_severity_to_dashboard("CRITICAL") == "CRITICAL"
    assert map_severity_to_dashboard("HIGH") == "HIGH"
    assert map_severity_to_dashboard("MEDIUM") == "HIGH"  # Crucial rule: MEDIUM -> HIGH
    assert map_severity_to_dashboard("LOW") == "INFO"     # Crucial rule: LOW -> INFO
    assert map_severity_to_dashboard("NONE") == "INFO"


def test_event_schema_mapping():
    """Verify dictionary translation into Person 2's React dashboard format."""
    raw_event = {
        "event_id": "evt-test-1234",
        "timestamp": "2026-10-15T12:00:00Z",
        "source_ip": "185.220.101.47",
        "path": "/admin/backup.sql",
        "method": "GET",
        "attack_type": "DECOY_ACCESS",
        "severity": "HIGH",
        "risk_score": 80,
        "decoy_triggered": True,
        "reason": "Decoy hit",
        "action": "SYNTHETIC_RESPONSE",
        "evidence": ["Requested /admin/backup.sql", "Triggered canary"],
    }

    dash = map_event_to_dashboard(raw_event)

    assert dash["id"] == "evt-test-1234"
    assert dash["client_ip"] == "185.220.101.47"
    assert dash["endpoint"] == "/admin/backup.sql"
    assert dash["attack_type"] == "Decoy Route Access"
    assert dash["severity"] == "HIGH"
    assert dash["action_taken"] == "Decoy Served & IP Logged"
    assert dash["payload"] == "Requested /admin/backup.sql\nTriggered canary"
    assert dash["geo"] == "UNKNOWN"


def test_bridge_health(client: TestClient):
    """Test GET /health returns online status."""
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "healthy"
    assert data["port"] == 8001


def test_bridge_get_events_and_filtering(client: TestClient, test_persister: EventPersistence, sample_event: SecurityEvent, sample_critical_event: SecurityEvent):
    """Test GET /api/events with mapping and query filters."""
    test_persister.save_event(sample_event)
    test_persister.save_event(sample_critical_event)

    resp = client.get("/api/events")
    assert resp.status_code == 200
    events = resp.json()
    assert len(events) == 2

    # Check mapping fields on returned events
    first = events[0]
    assert "id" in first
    assert "client_ip" in first
    assert "endpoint" in first
    assert "payload" in first
    assert "severity" in first
    assert "action_taken" in first
    assert "geo" in first

    # Filter by severity
    crit_resp = client.get("/api/events?severity=CRITICAL")
    assert crit_resp.status_code == 200
    crit_events = crit_resp.json()
    assert len(crit_events) == 1
    assert crit_events[0]["severity"] == "CRITICAL"


def test_bridge_get_stats(client: TestClient, test_persister: EventPersistence, sample_event: SecurityEvent):
    """Test GET /api/stats returns dashboard KPI metrics."""
    test_persister.save_event(sample_event)

    resp = client.get("/api/stats")
    assert resp.status_code == 200
    stats = resp.json()

    assert stats["total_events"] == 1
    assert stats["decoy_hits"] == 1
    assert stats["unique_attacker_ips"] == 1
    assert "blocklist_size" in stats


def test_bridge_blacklist_lifecycle(client: TestClient):
    """Test quarantine blacklist endpoints: POST, GET, and DELETE."""
    # 1. Add IP to blacklist
    post_resp = client.post("/api/blacklist", json={"ip": "198.51.100.99", "reason": "Burst scanner"})
    assert post_resp.status_code == 200
    assert post_resp.json()["status"] == "blacklisted"
    assert post_resp.json()["blocklist_size"] == 1

    # 2. List blacklisted IPs
    list_resp = client.get("/api/blacklist")
    assert list_resp.status_code == 200
    items = list_resp.json()
    assert len(items) == 1
    assert items[0]["ip"] == "198.51.100.99"

    # 3. Check stats reflects blocklist
    stats_resp = client.get("/api/stats")
    assert stats_resp.json()["blocklist_size"] == 1

    # 4. Remove from blacklist
    del_resp = client.delete("/api/blacklist/198.51.100.99")
    assert del_resp.status_code == 200
    assert del_resp.json()["status"] == "removed"
    assert del_resp.json()["blocklist_size"] == 0


def test_cors_headers(client: TestClient):
    """Verify CORS wildcard header is present for Person 2's dashboard."""
    resp = client.get("/api/events", headers={"Origin": "http://localhost:8080"})
    assert resp.status_code == 200
    assert resp.headers.get("access-control-allow-origin") in ("*", "http://localhost:8080")
