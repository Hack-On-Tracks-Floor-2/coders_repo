"""Unit tests for Webhook Notifier (Discord, Slack, cooldown, limits, retries)."""

from unittest.mock import MagicMock, patch
import urllib.error
import pytest

from schemas import AttackType, SecurityAction, SecurityEvent, SeverityLevel
from webhook_notifier import DiscordNotifier, SlackNotifier, WebhookManager, truncate_str


def test_truncate_str():
    """Verify string truncation helper."""
    assert truncate_str("hello", 10) == "hello"
    assert truncate_str("hello world", 8) == "hello..."
    assert len(truncate_str("a" * 300, 256)) == 256
    assert truncate_str(None, 10) == ""


def test_discord_payload_building(sample_event: SecurityEvent):
    """Verify Discord embed structure and color codes."""
    notifier = DiscordNotifier(min_severity="MEDIUM")
    payload = notifier.build_payload(sample_event)

    assert "embeds" in payload
    assert len(payload["embeds"]) == 1
    embed = payload["embeds"][0]

    assert "title" in embed
    assert sample_event.attack_type.value in embed["title"]
    assert embed["color"] == DiscordNotifier.COLOR_MAP[SeverityLevel.HIGH]

    # Verify fields
    field_names = [f["name"] for f in embed["fields"]]
    assert "Attack Category" in field_names
    assert "Severity / Risk" in field_names
    assert "Deception Canary" in field_names
    assert "Evidence" in field_names

    # Canary marker
    canary_field = next(f for f in embed["fields"] if f["name"] == "Deception Canary")
    assert "DECOY TRAP TRIGGERED" in canary_field["value"]


def test_discord_field_limits_truncation(sample_event: SecurityEvent):
    """Verify Discord payload protects against Discord API limit errors."""
    notifier = DiscordNotifier()

    # Create event with giant fields exceeding Discord limits
    giant_reason = "X" * 2000  # Discord field value max is 1024
    giant_evidence = ["E" * 1500 for _ in range(5)]
    corrupt_event = sample_event.model_copy(
        update={"reason": giant_reason, "evidence": giant_evidence}
    )

    payload = notifier.build_payload(corrupt_event)
    embed = payload["embeds"][0]

    assert len(embed["title"]) <= 256
    for f in embed["fields"]:
        assert len(f["name"]) <= 256
        assert len(f["value"]) <= 1024


def test_slack_payload_building(sample_event: SecurityEvent):
    """Verify Slack Block Kit structure."""
    notifier = SlackNotifier(min_severity="MEDIUM")
    payload = notifier.build_payload(sample_event)

    assert "blocks" in payload
    blocks = payload["blocks"]
    assert len(blocks) >= 3

    header = blocks[0]["text"]["text"]
    assert "VOID Alert [HIGH]" in header
    assert sample_event.attack_type.value in header


def test_severity_threshold_filtering(sample_event: SecurityEvent, sample_low_event: SecurityEvent, sample_critical_event: SecurityEvent):
    """Test severity filtering for both Discord and Slack."""
    # Min severity HIGH
    discord = DiscordNotifier(min_severity=SeverityLevel.HIGH, alert_on_all_decoys=False)
    slack = SlackNotifier(min_severity=SeverityLevel.HIGH, alert_on_all_decoys=False)

    # Low event should NOT alert
    assert discord.should_alert(sample_low_event) is False
    assert slack.should_alert(sample_low_event) is False

    # Critical event SHOULD alert
    assert discord.should_alert(sample_critical_event) is True
    assert slack.should_alert(sample_critical_event) is True

    # Decoy event with alert_on_all_decoys=True should alert even if severity is LOW
    decoy_low = sample_low_event.model_copy(update={"decoy_triggered": True})
    discord_decoy = DiscordNotifier(min_severity=SeverityLevel.CRITICAL, alert_on_all_decoys=True)
    slack_decoy = SlackNotifier(min_severity=SeverityLevel.CRITICAL, alert_on_all_decoys=True)
    assert discord_decoy.should_alert(decoy_low) is True
    assert slack_decoy.should_alert(decoy_low) is True


def test_cooldown_deduplication(sample_event: SecurityEvent):
    """Verify per-IP + attack_type cooldown deduplication."""
    notifier = DiscordNotifier(cooldown_seconds=30.0)
    notifier.reset_cooldown()

    # First event passes cooldown
    assert notifier.check_and_update_cooldown(sample_event) is True

    # Second identical event from same IP and attack_type is suppressed
    assert notifier.check_and_update_cooldown(sample_event) is False

    # Event with different attack_type from same IP is allowed
    diff_atk = sample_event.model_copy(update={"attack_type": AttackType.SQL_INJECTION})
    assert notifier.check_and_update_cooldown(diff_atk) is True

    # Event with different source IP is allowed
    diff_ip = sample_event.model_copy(update={"source_ip": "10.0.0.99"})
    assert notifier.check_and_update_cooldown(diff_ip) is True

    # Reset cooldown -> allowed again
    notifier.reset_cooldown()
    assert notifier.check_and_update_cooldown(sample_event) is True


def test_mock_dispatch_when_no_url(sample_event: SecurityEvent):
    """With no webhook URL configured, dispatch logs a mock and returns True."""
    discord = DiscordNotifier(webhook_url=None)
    slack = SlackNotifier(webhook_url=None)

    assert discord.send_direct(sample_event, check_cooldown=False) is True
    assert slack.send_direct(sample_event, check_cooldown=False) is True


def test_retry_on_network_failure(sample_event: SecurityEvent):
    """Test 2-attempt retry with backoff upon network failures."""
    notifier = DiscordNotifier(webhook_url="https://discord.com/api/webhooks/mock_test")

    with patch("urllib.request.urlopen") as mock_urlopen, patch("time.sleep") as mock_sleep:
        # First call fails, second call succeeds
        mock_resp = MagicMock()
        mock_resp.status = 204
        mock_resp.__enter__.return_value = mock_resp
        mock_urlopen.side_effect = [urllib.error.URLError("Connection reset"), mock_resp]

        success = notifier.send_direct(sample_event, check_cooldown=False)
        assert success is True
        assert mock_urlopen.call_count == 2
        mock_sleep.assert_called_once_with(0.5)


def test_webhook_manager_dispatch(sample_event: SecurityEvent):
    """Verify WebhookManager coordinates both dispatchers."""
    mgr = WebhookManager(discord_url=None, slack_url=None)
    # Should dispatch without raising
    mgr.dispatch(sample_event, sync=True)
