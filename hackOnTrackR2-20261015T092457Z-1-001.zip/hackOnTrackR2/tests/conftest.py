"""Pytest configuration and shared test fixtures for VOID Person 3."""

import os
from pathlib import Path
import tempfile
import uuid
import pytest

from schemas import AttackType, SecurityAction, SecurityEvent, SeverityLevel
from persistence.db_adapter import EventPersistence


@pytest.fixture
def temp_db_path(tmp_path: Path) -> str:
    """Provide a path to a temporary SQLite database."""
    db_file = tmp_path / f"test_void_{uuid.uuid4().hex[:8]}.db"
    return str(db_file)


@pytest.fixture
def test_persister(temp_db_path: str) -> EventPersistence:
    """Provide an isolated, freshly initialized EventPersistence instance."""
    persister = EventPersistence(db_path=temp_db_path)
    yield persister
    persister.close()


@pytest.fixture
def sample_event() -> SecurityEvent:
    """Standard sample security event."""
    return SecurityEvent(
        event_id="6019ed80-f521-4756-b034-a5042339b7a6",
        timestamp="2026-10-15T06:13:11.431185+00:00",
        path="/admin/backup.sql",
        method="GET",
        attack_type=AttackType.DECOY_ACCESS,
        severity=SeverityLevel.HIGH,
        risk_score=75,
        decoy_triggered=True,
        source_ip="192.168.1.45",
        reason="Request matched configured decoy route: 'Database Backup Decoy'",
        action=SecurityAction.SYNTHETIC_RESPONSE,
        rule_ids=["DECOY-001"],
        evidence=[
            "Requested path: /admin/backup.sql",
            "Matched normalized decoy: /admin/backup.sql",
            "Template served: BACKUP_SQL_TEMPLATE",
        ],
        request_id="88556e99-b5df-442b-b60f-4901497423b1",
    )


@pytest.fixture
def sample_low_event() -> SecurityEvent:
    """Low severity, non-decoy event."""
    return SecurityEvent(
        event_id=str(uuid.uuid4()),
        timestamp="2026-10-15T06:14:00.000000+00:00",
        path="/api/products",
        method="GET",
        attack_type=AttackType.NONE,
        severity=SeverityLevel.LOW,
        risk_score=10,
        decoy_triggered=False,
        source_ip="10.0.0.5",
        reason="Normal baseline traffic",
        action=SecurityAction.ALLOW,
        rule_ids=[],
        evidence=[],
        request_id=str(uuid.uuid4()),
    )


@pytest.fixture
def sample_critical_event() -> SecurityEvent:
    """Critical severity SQLi attack event."""
    return SecurityEvent(
        event_id=str(uuid.uuid4()),
        timestamp="2026-10-15T06:15:00.000000+00:00",
        path="/api/products",
        method="GET",
        attack_type=AttackType.SQL_INJECTION,
        severity=SeverityLevel.CRITICAL,
        risk_score=95,
        decoy_triggered=False,
        source_ip="45.141.84.120",
        reason="SQL injection signature detected in parameter 'q'",
        action=SecurityAction.REQUEST_TEMPORARY_BLOCK,
        rule_ids=["SQLI-001"],
        evidence=["Parameter 'q' contains: ' OR 1=1 --"],
        request_id=str(uuid.uuid4()),
    )
