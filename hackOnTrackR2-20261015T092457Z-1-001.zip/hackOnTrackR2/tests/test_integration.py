"""Unit and integration tests for integration entrypoint (wire_up and poller)."""

from unittest.mock import MagicMock, patch
import pytest

from integration import wire_up, poll_events
from persistence.db_adapter import EventPersistence
from schemas import AttackType, SecurityAction, SecurityEvent, SeverityLevel
from webhook_notifier import WebhookManager


class MockEventStore:
    """Mock store mimicking Person 1's InMemoryEventStore."""

    def __init__(self):
        self.subscribers = []

    def register_subscriber(self, callback):
        self.subscribers.append(callback)

    def emit(self, event: SecurityEvent):
        for sub in self.subscribers:
            sub(event)


def test_wire_up_subscriber(test_persister: EventPersistence, sample_event: SecurityEvent):
    """Test wire_up registering with event_store and processing events."""
    mock_store = MockEventStore()
    mock_mgr = MagicMock(spec=WebhookManager)

    db, mgr, callback = wire_up(
        event_store=mock_store,
        db=test_persister,
        webhook_mgr=mock_mgr,
    )

    assert len(mock_store.subscribers) == 1
    assert mock_store.subscribers[0] == callback

    # Emit event via mock store
    mock_store.emit(sample_event)

    # Verify saved in persister
    assert db.get_event_count() == 1
    saved = db.query_events()[0]
    assert saved["event_id"] == sample_event.event_id

    # Verify webhook manager dispatch was invoked
    mock_mgr.dispatch.assert_called_once_with(sample_event, sync=False)


def test_poll_events_deduplication(test_persister: EventPersistence, sample_event: SecurityEvent):
    """Test out-of-process poller querying mock endpoint and deduplicating events."""
    mock_mgr = MagicMock(spec=WebhookManager)

    raw_event_data = [sample_event.model_dump(mode="json")]

    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_resp = MagicMock()
        mock_resp.status = 200
        import json
        mock_resp.read.return_value = json.dumps(raw_event_data).encode("utf-8")
        mock_resp.__enter__.return_value = mock_resp
        mock_urlopen.return_value = mock_resp

        # First poll: ingests 1 event
        ingested = poll_events(
            target_url="http://127.0.0.1:8000",
            db=test_persister,
            webhook_mgr=mock_mgr,
            once=True,
        )
        assert ingested == 1
        assert test_persister.get_event_count() == 1

        # Second poll: same event returned, must be deduplicated
        ingested_again = poll_events(
            target_url="http://127.0.0.1:8000",
            db=test_persister,
            webhook_mgr=mock_mgr,
            once=True,
        )
        assert ingested_again == 0
        assert test_persister.get_event_count() == 1
