"""Unit tests for EventPersistence (SQLite WAL, queries, deduplication, error safety)."""

from datetime import datetime, timedelta, timezone
import uuid
import pytest

from schemas import AttackType, SecurityAction, SecurityEvent, SeverityLevel
from persistence.db_adapter import EventPersistence


def test_persistence_round_trip(test_persister: EventPersistence, sample_event: SecurityEvent):
    """Test saving an event and querying it back from the database."""
    assert test_persister.save_event(sample_event) is True

    # Total count check
    assert test_persister.get_event_count() == 1

    # Query events
    events = test_persister.query_events(limit=10)
    assert len(events) == 1

    saved = events[0]
    assert saved["event_id"] == sample_event.event_id
    assert saved["path"] == sample_event.path
    assert saved["attack_type"] == sample_event.attack_type.value
    assert saved["severity"] == sample_event.severity.value
    assert saved["risk_score"] == sample_event.risk_score
    assert saved["decoy_triggered"] is True
    assert saved["source_ip"] == sample_event.source_ip
    assert isinstance(saved["evidence"], list)
    assert len(saved["evidence"]) == 3


def test_idempotent_insert_deduplication(test_persister: EventPersistence, sample_event: SecurityEvent):
    """Saving the exact same event_id multiple times must NOT duplicate or raise."""
    assert test_persister.save_event(sample_event) is True
    assert test_persister.save_event(sample_event) is True
    assert test_persister.save_event(sample_event) is True

    assert test_persister.get_event_count() == 1


def test_query_filters(test_persister: EventPersistence, sample_event: SecurityEvent, sample_low_event: SecurityEvent, sample_critical_event: SecurityEvent):
    """Verify filtering by severity, decoy_only, and source_ip."""
    test_persister.save_event(sample_event)
    test_persister.save_event(sample_low_event)
    test_persister.save_event(sample_critical_event)

    assert test_persister.get_event_count() == 3

    # Filter by severity
    crit_events = test_persister.query_events(severity="CRITICAL")
    assert len(crit_events) == 1
    assert crit_events[0]["event_id"] == sample_critical_event.event_id

    # Filter by decoy_only
    decoys = test_persister.query_events(decoy_only=True)
    assert len(decoys) == 1
    assert decoys[0]["event_id"] == sample_event.event_id

    # Filter by source_ip
    ip_events = test_persister.query_events(source_ip="10.0.0.5")
    assert len(ip_events) == 1
    assert ip_events[0]["event_id"] == sample_low_event.event_id


def test_get_stats_aggregation(test_persister: EventPersistence, sample_event: SecurityEvent, sample_critical_event: SecurityEvent):
    """Verify statistical analytics aggregations."""
    test_persister.save_event(sample_event)
    test_persister.save_event(sample_critical_event)

    stats = test_persister.get_stats()
    assert stats["total"] == 2
    assert stats["decoy_hits"] == 1
    assert stats["by_severity"]["HIGH"] == 1
    assert stats["by_severity"]["CRITICAL"] == 1
    assert stats["by_attack_type"]["DECOY_ACCESS"] == 1
    assert stats["by_attack_type"]["SQL_INJECTION"] == 1
    assert stats["unique_ips"] == 2
    assert stats["aggregate_system_risk"] == 95
    assert len(stats["top_ips"]) == 2


def test_purge_older_than(test_persister: EventPersistence):
    """Verify purging of records older than X days."""
    old_time = (datetime.now(timezone.utc) - timedelta(days=10)).isoformat()
    recent_time = (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()

    old_event = SecurityEvent(
        event_id=str(uuid.uuid4()),
        timestamp=old_time,
        path="/old",
        method="GET",
        attack_type=AttackType.NONE,
        severity=SeverityLevel.LOW,
        risk_score=5,
        decoy_triggered=False,
        source_ip="1.1.1.1",
        reason="Old log",
        action=SecurityAction.LOG_ONLY,
    )
    recent_event = SecurityEvent(
        event_id=str(uuid.uuid4()),
        timestamp=recent_time,
        path="/recent",
        method="GET",
        attack_type=AttackType.NONE,
        severity=SeverityLevel.LOW,
        risk_score=5,
        decoy_triggered=False,
        source_ip="2.2.2.2",
        reason="Recent log",
        action=SecurityAction.LOG_ONLY,
    )

    test_persister.save_event(old_event)
    test_persister.save_event(recent_event)
    assert test_persister.get_event_count() == 2

    purged = test_persister.purge_older_than(days=5)
    assert purged == 1
    assert test_persister.get_event_count() == 1

    remaining = test_persister.query_events()
    assert remaining[0]["event_id"] == recent_event.event_id


def test_error_suppression_never_raises(test_persister: EventPersistence):
    """Persister must never raise into Person 1's request path even with invalid inputs."""
    # Pass completely malformed data
    res = test_persister.save_event(None)  # type: ignore
    assert res is False

    res = test_persister.save_event({"invalid": "corrupt"})
    # Should catch gracefully and return False or handle safely without raising
    assert isinstance(res, bool)


def test_blacklist_management(test_persister: EventPersistence):
    """Test adding, checking, listing, and removing blacklisted IPs."""
    assert test_persister.is_ip_blacklisted("198.51.100.1") is False

    # Add to blacklist
    assert test_persister.add_blacklisted_ip("198.51.100.1", reason="Malicious brute force") is True
    assert test_persister.is_ip_blacklisted("198.51.100.1") is True

    # List
    ips = test_persister.get_blacklisted_ips()
    assert len(ips) == 1
    assert ips[0]["ip"] == "198.51.100.1"

    # Remove
    assert test_persister.remove_blacklisted_ip("198.51.100.1") is True
    assert test_persister.is_ip_blacklisted("198.51.100.1") is False
