# VOID — AI-Powered Cyber Defense Backend
Please refer to [void-backend/README.md](void-backend/README.md) for full architecture, installation, API contracts, and Person 2 / Person 3 integration guides.

### Quick Start
```powershell
# Windows PowerShell
.\.venv\Scripts\Activate.ps1
cd void-backend
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

### Run Tests
```powershell
.\.venv\Scripts\python.exe -m pytest
```
