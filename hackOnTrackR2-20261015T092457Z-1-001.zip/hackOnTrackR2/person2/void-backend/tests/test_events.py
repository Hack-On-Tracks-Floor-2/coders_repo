"""Test event store, telemetry retrieval, pagination, filters, and subscriber interface."""

import pytest
from fastapi.testclient import TestClient

from app.event_logger import event_store
from app.main import app
from app.schemas import AttackType, SecurityAction, SecurityEvent, SeverityLevel

client = TestClient(app)


def setup_function():
    event_store.clear()


def create_sample_event(
    path: str = "/test",
    attack_type: AttackType = AttackType.NONE,
    severity: SeverityLevel = SeverityLevel.LOW,
    decoy_triggered: bool = False,
    source_ip: str = "127.0.0.1",
    score: int = 10,
) -> SecurityEvent:
    ev = SecurityEvent(
        path=path,
        method="GET",
        attack_type=attack_type,
        severity=severity,
        risk_score=score,
        decoy_triggered=decoy_triggered,
        source_ip=source_ip,
        reason="Test event",
        action=SecurityAction.LOG_ONLY if not decoy_triggered else SecurityAction.SYNTHETIC_RESPONSE,
    )
    event_store.add_event(ev)
    return ev


def test_events_retrieval_and_pagination():
    """Verify event queries support pagination parameters (limit, offset)."""
    for i in range(15):
        create_sample_event(path=f"/test/{i}", score=i * 2)

    assert event_store.count() == 15

    # Page 1 (limit 5)
    r1 = client.get("/events?limit=5&offset=0")
    assert r1.status_code == 200
    page1 = r1.json()
    assert len(page1) == 5

    # Page 2 (limit 5, offset 5)
    r2 = client.get("/events?limit=5&offset=5")
    assert r2.status_code == 200
    page2 = r2.json()
    assert len(page2) == 5

    # Ensure no overlap between page 1 and page 2
    ids_page1 = {e["event_id"] for e in page1}
    ids_page2 = {e["event_id"] for e in page2}
    assert ids_page1.isdisjoint(ids_page2)


def test_events_filtering():
    """Verify events endpoint filters by severity, attack_type, and decoy_only."""
    create_sample_event(path="/p1", severity=SeverityLevel.LOW, attack_type=AttackType.NONE)
    create_sample_event(path="/admin/backup.sql", severity=SeverityLevel.HIGH, attack_type=AttackType.DECOY_ACCESS, decoy_triggered=True)
    create_sample_event(path="/p2", severity=SeverityLevel.CRITICAL, attack_type=AttackType.SQL_INJECTION)

    # Filter by severity
    r_high = client.get("/events?severity=HIGH")
    assert r_high.status_code == 200
    items = r_high.json()
    assert len(items) == 1
    assert items[0]["severity"] == "HIGH"

    # Filter by decoy_only
    r_decoy = client.get("/events?decoy_only=true")
    assert r_decoy.status_code == 200
    items_decoy = r_decoy.json()
    assert len(items_decoy) == 1
    assert items_decoy[0]["decoy_triggered"] is True

    # Filter by attack_type
    r_sqli = client.get("/events?attack_type=SQL_INJECTION")
    assert r_sqli.status_code == 200
    items_sqli = r_sqli.json()
    assert len(items_sqli) == 1
    assert items_sqli[0]["attack_type"] == "SQL_INJECTION"


def test_stats_calculated_from_real_events():
    """Verify /stats calculates metrics directly from recorded events without fabrication."""
    create_sample_event(path="/admin/backup.sql", severity=SeverityLevel.HIGH, attack_type=AttackType.DECOY_ACCESS, decoy_triggered=True, source_ip="192.168.1.10")
    create_sample_event(path="/api/exec", severity=SeverityLevel.CRITICAL, attack_type=AttackType.COMMAND_INJECTION, decoy_triggered=False, source_ip="192.168.1.20")
    create_sample_event(path="/api/products", severity=SeverityLevel.LOW, attack_type=AttackType.NONE, decoy_triggered=False, source_ip="192.168.1.10")

    response = client.get("/stats")
    assert response.status_code == 200
    stats = response.json()

    assert stats["total_events"] == 3
    assert stats["decoy_interactions"] == 1
    assert stats["unique_ips"] == 2
    assert stats["severity_counts"]["HIGH"] == 1
    assert stats["severity_counts"]["CRITICAL"] == 1
    assert stats["severity_counts"]["LOW"] == 1
    assert stats["attack_type_counts"]["DECOY_ACCESS"] == 1
    assert stats["attack_type_counts"]["COMMAND_INJECTION"] == 1


def test_person3_subscriber_callback_interface():
    """Verify Person 3 can register a subscriber callback to receive streamed security events."""
    received_events = []

    def mock_person3_webhook_notifier(event: SecurityEvent):
        # Simulates Person 3's Discord/Slack webhook or SQLite persister
        received_events.append(event)

    event_store.register_subscriber(mock_person3_webhook_notifier)

    # Trigger a real request through FastAPI
    client.get("/admin/backup.sql")

    assert len(received_events) >= 1
    last_event = received_events[-1]
    assert last_event.path == "/admin/backup.sql"
    assert last_event.attack_type == AttackType.DECOY_ACCESS
    assert last_event.decoy_triggered is True
    assert last_event.source_ip is not None


def test_recommendations_endpoint():
    """Verify /recommendations returns active response recommendations."""
    client.get("/admin/backup.sql")

    response = client.get("/recommendations")
    assert response.status_code == 200
    recs = response.json()
    assert len(recs) >= 1
    assert recs[0]["action_type"] in [
        "REQUIRE_ANALYST_REVIEW",
        "APPLY_RATE_LIMIT",
        "REQUEST_TEMPORARY_BLOCK",
        "INCREASE_MONITORING",
        "CONTINUE_MONITORING",
    ]
    assert "remediation_steps" in recs[0]
