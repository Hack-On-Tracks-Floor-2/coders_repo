"""Test legitimate application traffic handling and privacy sanitization."""

import pytest
from fastapi.testclient import TestClient

from app.event_logger import event_store
from app.main import app

client = TestClient(app)


def setup_function():
    event_store.clear()


def test_products_endpoint_legitimate_traffic():
    """Verify /api/products returns legitimate products catalog without flagging security events."""
    initial_event_count = event_store.count()

    response = client.get("/api/products")
    assert response.status_code == 200
    products = response.json()
    assert isinstance(products, list)
    assert len(products) > 0
    assert "name" in products[0]
    assert "price" in products[0]

    # Clean legitimate traffic should not generate an attack event
    assert event_store.count() == initial_event_count


def test_products_category_filtering():
    """Verify category filtering works as intended for legitimate shoppers."""
    response = client.get("/api/products?category=Deception+Tech")
    assert response.status_code == 200
    items = response.json()
    assert len(items) == 1
    assert items[0]["name"] == "Canary Core Sensor Pack"


def test_profile_endpoint_legitimate_traffic():
    """Verify /api/profile returns authorized user profile."""
    response = client.get(
        "/api/profile",
        headers={"Authorization": "Bearer legitimate-operator-token-sample"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["username"] == "alex_secops"
    assert data["role"] == "Senior Defense Analyst"
    assert "email" in data


def test_sensitive_headers_sanitization():
    """Ensure sensitive headers (Authorization, Cookie, API keys) are not leaked in event logs."""
    from app.middleware import sanitize_headers

    headers = {
        "authorization": "Bearer secret_jwt_token_12345",
        "cookie": "session_id=confidential_session_token",
        "x-api-key": "secret_api_key_abcde",
        "user-agent": "Mozilla/5.0 Legitimate Client",
        "content-type": "application/json",
    }
    sanitized = sanitize_headers(headers)
    assert sanitized["authorization"] == "[REDACTED_CREDENTIAL]"
    assert sanitized["cookie"] == "[REDACTED_CREDENTIAL]"
    assert sanitized["x-api-key"] == "[REDACTED_CREDENTIAL]"
    assert sanitized["user-agent"] == "Mozilla/5.0 Legitimate Client"
