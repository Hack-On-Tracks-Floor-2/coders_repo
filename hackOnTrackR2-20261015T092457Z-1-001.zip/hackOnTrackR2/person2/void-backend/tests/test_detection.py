"""Test detection engine rules, indicators, and risk scoring."""

import pytest
from app.detector import (
    CommandInjectionRule,
    DecoyAccessRule,
    DetectionEngine,
    PathTraversalRule,
    ReconnaissanceRule,
    RequestBurstRule,
    RiskScoringEngine,
    SqlInjectionRule,
    detection_engine,
)
from app.schemas import AttackType, DefensiveActionType, SecurityEvent, SeverityLevel


@pytest.fixture(autouse=True)
def reset_detection_state():
    """Reset detection engine state before every test."""
    detection_engine.reset_state()


def test_path_traversal_detection():
    """Verify path traversal indicators are flagged accurately."""
    rule = PathTraversalRule()

    # Suspicious dot-dot path
    res = rule.evaluate("GET", "/files/../../etc/passwd", "/files/etc/passwd", {}, "127.0.0.1", {})
    assert res is not None
    assert res.attack_type == AttackType.PATH_TRAVERSAL
    assert res.rule_id == "TRAV-001"
    assert res.severity == SeverityLevel.HIGH

    # Suspicious query parameter
    res2 = rule.evaluate("GET", "/api/download", "/api/download", {"file": "....//win.ini"}, "127.0.0.1", {})
    assert res2 is not None
    assert res2.attack_type == AttackType.PATH_TRAVERSAL

    # Normal request must NOT trigger traversal
    res3 = rule.evaluate("GET", "/api/products", "/api/products", {"category": "hardware"}, "127.0.0.1", {})
    assert res3 is None


def test_sql_injection_detection():
    """Verify SQL injection patterns are detected while avoiding false positives on clean queries."""
    rule = SqlInjectionRule()

    # Classic tautology
    res = rule.evaluate("GET", "/api/products", "/api/products", {"q": "' OR 1=1 -- "}, "127.0.0.1", {})
    assert res is not None
    assert res.attack_type == AttackType.SQL_INJECTION
    assert res.rule_id == "INJ-SQL-001"

    # UNION SELECT
    res2 = rule.evaluate("GET", "/api/search", "/api/search", {"term": "1 UNION SELECT username, password FROM users"}, "127.0.0.1", {})
    assert res2 is not None
    assert res2.attack_type == AttackType.SQL_INJECTION

    # Normal queries should NOT trigger SQLi
    res3 = rule.evaluate("GET", "/api/products", "/api/products", {"search": "laptop bag", "order": "asc"}, "127.0.0.1", {})
    assert res3 is None


def test_command_injection_detection():
    """Verify shell command injection patterns are identified."""
    rule = CommandInjectionRule()

    # Piped command
    res = rule.evaluate("GET", "/api/ping", "/api/ping", {"host": "127.0.0.1 | whoami"}, "127.0.0.1", {})
    assert res is not None
    assert res.attack_type == AttackType.COMMAND_INJECTION
    assert res.rule_id == "INJ-CMD-001"

    # Chained semicolon command
    res2 = rule.evaluate("GET", "/api/diag", "/api/diag", {"target": "localhost; cat /etc/passwd"}, "127.0.0.1", {})
    assert res2 is not None

    # Normal input should not trigger
    res3 = rule.evaluate("GET", "/api/profile", "/api/profile", {"view": "summary"}, "127.0.0.1", {})
    assert res3 is None


def test_request_burst_detection():
    """Verify deterministic request burst detection triggered above threshold."""
    burst_rule = RequestBurstRule(threshold=4, window_seconds=5.0)

    # First 3 requests under threshold
    for _ in range(3):
        res = burst_rule.evaluate("GET", "/api/products", "/api/products", {}, "192.168.1.100", {})
        assert res is None

    # 4th request reaches threshold (4 in 5s window)
    res4 = burst_rule.evaluate("GET", "/api/products", "/api/products", {}, "192.168.1.100", {})
    assert res4 is not None
    assert res4.attack_type == AttackType.REQUEST_BURST
    assert res4.rule_id == "BURST-001"

    # Different IP should not be affected
    res_other = burst_rule.evaluate("GET", "/api/products", "/api/products", {}, "192.168.1.101", {})
    assert res_other is None


def test_reconnaissance_pattern_detection():
    """Verify reconnaissance sweeps across multiple sensitive paths trigger alert."""
    recon_rule = ReconnaissanceRule(threshold=3, window_seconds=10.0)

    # Probe 1: .env
    r1 = recon_rule.evaluate("GET", "/.env", "/.env", {}, "10.0.0.50", {})
    assert r1 is None

    # Probe 2: .git/config
    r2 = recon_rule.evaluate("GET", "/.git/config", "/.git/config", {}, "10.0.0.50", {})
    assert r2 is None

    # Probe 3: /admin/backup.sql (3rd distinct sensitive endpoint)
    r3 = recon_rule.evaluate("GET", "/admin/backup.sql", "/admin/backup.sql", {}, "10.0.0.50", {})
    assert r3 is not None
    assert r3.attack_type == AttackType.RECONNAISSANCE
    assert r3.rule_id == "RECON-001"
    assert r3.severity == SeverityLevel.HIGH


def test_risk_scoring_bounds_and_dampening():
    """Verify risk scores stay strictly within 0-100 and dampen repeated signals."""
    scorer = RiskScoringEngine()

    from app.detector import DetectionResult

    # Single finding
    f1 = DetectionResult("TEST-01", AttackType.SQL_INJECTION, SeverityLevel.HIGH, 40, "SQL injection", ["evidence"])
    score1, sev1, _ = scorer.calculate_event_score([f1])
    assert 0 <= score1 <= 100
    assert score1 == 40
    assert sev1 == SeverityLevel.MEDIUM

    # Multiple findings combine with dampening
    f2 = DetectionResult("TEST-02", AttackType.PATH_TRAVERSAL, SeverityLevel.HIGH, 40, "Traversal", ["evidence"])
    f3 = DetectionResult("TEST-03", AttackType.DECOY_ACCESS, SeverityLevel.HIGH, 45, "Decoy", ["evidence"])
    score_multi, sev_multi, _ = scorer.calculate_event_score([f1, f2, f3])
    # 45 + (40 * 0.35) + (40 * 0.35) = 45 + 14 + 14 = 73
    assert 0 <= score_multi <= 100
    assert score_multi == 73
    assert sev_multi == SeverityLevel.HIGH

    # Extreme theoretical score must clamp at 100
    f_huge = [
        DetectionResult(f"TEST-{i}", AttackType.SQL_INJECTION, SeverityLevel.CRITICAL, 90, "Massive", ["evidence"])
        for i in range(10)
    ]
    score_extreme, sev_extreme, _ = scorer.calculate_event_score(f_huge)
    assert score_extreme == 100
    assert sev_extreme == SeverityLevel.CRITICAL


def test_defensive_recommendation_policies():
    """Verify response engine maps event severity to appropriate defensive actions."""
    from app.response_engine import response_engine

    response_engine.clear()

    # Normal low-risk event
    low_event = SecurityEvent(
        path="/api/products",
        method="GET",
        attack_type=AttackType.NONE,
        severity=SeverityLevel.LOW,
        risk_score=0,
        decoy_triggered=False,
        source_ip="192.168.1.1",
        reason="Baseline",
        action="ALLOW",
    )
    rec_low = response_engine.evaluate_event(low_event, aggregate_ip_risk=0)
    assert rec_low.action_type == DefensiveActionType.CONTINUE_MONITORING
    assert rec_low.human_approval_required is False

    # Decoy trigger event
    decoy_event = SecurityEvent(
        path="/admin/backup.sql",
        method="GET",
        attack_type=AttackType.DECOY_ACCESS,
        severity=SeverityLevel.HIGH,
        risk_score=45,
        decoy_triggered=True,
        source_ip="192.168.1.2",
        reason="Decoy accessed",
        action="SYNTHETIC_RESPONSE",
    )
    rec_decoy = response_engine.evaluate_event(decoy_event, aggregate_ip_risk=45)
    assert rec_decoy.action_type == DefensiveActionType.REQUIRE_ANALYST_REVIEW
    assert rec_decoy.human_approval_required is True

    # High risk / burst
    burst_event = SecurityEvent(
        path="/api/profile",
        method="GET",
        attack_type=AttackType.REQUEST_BURST,
        severity=SeverityLevel.HIGH,
        risk_score=55,
        decoy_triggered=False,
        source_ip="192.168.1.3",
        reason="Burst traffic",
        action="LOG_ONLY",
    )
    rec_burst = response_engine.evaluate_event(burst_event, aggregate_ip_risk=55)
    assert rec_burst.action_type == DefensiveActionType.APPLY_RATE_LIMIT

    # Critical threat
    crit_event = SecurityEvent(
        path="/api/exec",
        method="GET",
        attack_type=AttackType.COMMAND_INJECTION,
        severity=SeverityLevel.CRITICAL,
        risk_score=85,
        decoy_triggered=False,
        source_ip="192.168.1.4",
        reason="Critical command injection",
        action="LOG_ONLY",
    )
    rec_crit = response_engine.evaluate_event(crit_event, aggregate_ip_risk=85)
    assert rec_crit.action_type == DefensiveActionType.REQUEST_TEMPORARY_BLOCK
    assert rec_crit.human_approval_required is True
