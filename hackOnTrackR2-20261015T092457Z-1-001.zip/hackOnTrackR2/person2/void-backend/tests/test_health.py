"""Test health check and application bootstrap."""

import pytest
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health_check_returns_200():
    """Verify /health returns HTTP 200 with operational status."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert data["version"] == "1.0.0"
    assert "uptime_seconds" in data
    assert data["uptime_seconds"] >= 0
    assert data["components"]["detector"] == "active"
    assert data["components"]["event_store"] == "active"
    assert data["components"]["response_engine"] == "active"
    assert data["components"]["decoys"] == "active"
    assert "X-Request-ID" in response.headers


def test_unhandled_route_returns_safe_404():
    """Verify unhandled paths return standard 404 without leaking server details."""
    response = client.get("/nonexistent/endpoint/path")
    assert response.status_code == 404
    data = response.json()
    assert "detail" in data
    assert "X-Request-ID" in response.headers


def test_invalid_input_returns_safe_422():
    """Verify malformed query parameters produce consistent 422 JSON validation errors."""
    response = client.get("/events?limit=-5")
    assert response.status_code == 422
    data = response.json()
    assert data["error"] == "Validation Error"
    assert data["status_code"] == 422
    assert "detail" in data
    assert "request_id" in data
    assert "timestamp" in data


def test_invalid_order_param_returns_safe_422():
    """Verify pattern validation returns 422 when sort order is invalid."""
    response = client.get("/events?order=invalid_sort")
    assert response.status_code == 422
    data = response.json()
    assert data["error"] == "Validation Error"

