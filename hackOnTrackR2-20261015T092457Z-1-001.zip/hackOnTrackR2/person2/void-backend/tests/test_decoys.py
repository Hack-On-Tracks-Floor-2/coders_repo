"""Test decoy interception, path normalization, and synthetic response safety."""

import pytest
from fastapi.testclient import TestClient

from app.decoys import decoy_registry, normalize_request_path
from app.event_logger import event_store
from app.main import app
from app.schemas import AttackType, SecurityAction, SeverityLevel

client = TestClient(app)


def setup_function():
    event_store.clear()


def test_path_normalization_handles_bypasses():
    """Verify normalize_request_path resolves slashes, encodings, and relative segments."""
    assert normalize_request_path("/admin/backup.sql") == "/admin/backup.sql"
    assert normalize_request_path("/admin//backup.sql") == "/admin/backup.sql"
    assert normalize_request_path("/admin/backup.sql/") == "/admin/backup.sql"
    assert normalize_request_path("/admin/%62ackup.sql") == "/admin/backup.sql"
    assert normalize_request_path("/api/../admin/backup.sql") == "/admin/backup.sql"
    assert normalize_request_path("/admin/backup.sql?version=1") == "/admin/backup.sql"


def test_decoy_backup_sql_returns_synthetic_data():
    """Verify /admin/backup.sql is intercepted, returns fake SQL dump, and creates security event."""
    response = client.get("/admin/backup.sql")
    assert response.status_code == 200
    assert "application/x-sql" in response.headers["content-type"]
    assert response.headers.get("X-VOID-Interception") == "DECOY_TRIGGERED"
    assert response.headers.get("X-Synthetic-Artifact") == "VOID-DECOY-DUMP-v1"

    body = response.text
    assert "VOID DEFENSE SYSTEM - SYNTHETIC DECOY BACKUP ARTIFACT" in body
    assert "FABRICATED DATA FOR DECEPTION PURPOSES ONLY" in body
    assert "synthetic_corp_admin" in body

    # Verify event generation
    events = event_store.get_events()
    assert len(events) == 1
    ev = events[0]
    assert ev.path == "/admin/backup.sql"
    assert ev.attack_type == AttackType.DECOY_ACCESS
    assert ev.decoy_triggered is True
    assert ev.severity in (SeverityLevel.HIGH, SeverityLevel.CRITICAL)
    assert ev.action == SecurityAction.SYNTHETIC_RESPONSE
    assert "DECOY-001" in ev.rule_ids
    assert ev.risk_score >= 40


def test_decoy_users_export_returns_synthetic_data():
    """Verify /api/v1/internal/users/export returns synthetic employee directory."""
    response = client.get("/api/v1/internal/users/export")
    assert response.status_code == 200
    assert response.headers.get("X-VOID-Interception") == "DECOY_TRIGGERED"
    assert response.headers.get("X-Synthetic-Artifact") == "VOID-USER-EXPORT-v1"

    data = response.json()
    assert data["export_metadata"]["status"] == "COMPLETED"
    assert "Synthetic Canary Dataset" in data["export_metadata"]["synthetic_disclaimer"]
    assert len(data["users"]) == 3
    assert data["users"][0]["synthetic_token_canary"].startswith("CANARY_TOKEN_")

    events = event_store.get_events()
    assert len(events) == 1
    assert events[0].decoy_triggered is True


def test_decoy_debug_config_returns_synthetic_data():
    """Verify /api/debug/config returns synthetic debug settings."""
    response = client.get("/api/debug/config")
    assert response.status_code == 200
    assert response.headers.get("X-VOID-Interception") == "DECOY_TRIGGERED"
    assert response.headers.get("X-Synthetic-Artifact") == "VOID-DEBUG-CONFIG-v1"

    data = response.json()
    assert data["service"] == "void-internal-config-service"
    assert data["environment"] == "staging-sandbox-demo"
    assert "Purely synthetic test values" in data["synthetic_notice"]

    events = event_store.get_events()
    assert len(events) == 1
    assert events[0].decoy_triggered is True


def test_decoy_normalization_interception():
    """Verify normalized requests with extra slashes or relative paths still hit the decoy trap."""
    response = client.get("/admin//backup.sql")
    assert response.status_code == 200
    assert response.headers.get("X-VOID-Interception") == "DECOY_TRIGGERED"

    events = event_store.get_events()
    assert len(events) == 1
    assert events[0].decoy_triggered is True
