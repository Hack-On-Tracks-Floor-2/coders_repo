"""Test real uvicorn server startup and HTTP socket binding on port 8000."""

import threading
import time
import httpx
import pytest
import uvicorn

from app.main import app


@pytest.fixture(scope="module")
def run_live_server():
    """Run uvicorn server in a separate thread on port 8000 for live integration testing."""
    config = uvicorn.Config(
        app,
        host="127.0.0.1",
        port=8000,
        log_level="warning",
        lifespan="on",
    )
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    # Wait until server is listening
    started = False
    for _ in range(50):
        try:
            with httpx.Client(timeout=1.0) as client:
                r = client.get("http://127.0.0.1:8000/health")
                if r.status_code == 200:
                    started = True
                    break
        except Exception:
            time.sleep(0.1)

    assert started, "Server failed to bind and respond on http://127.0.0.1:8000/health"
    yield
    server.should_exit = True


def test_live_server_endpoints(run_live_server):
    """Test full HTTP lifecycle against live running server on port 8000."""
    with httpx.Client(base_url="http://127.0.0.1:8000", timeout=5.0) as client:
        # 1. Health check
        r_health = client.get("/health")
        assert r_health.status_code == 200
        assert r_health.json()["status"] == "ok"

        # 2. Legitimate endpoint
        r_products = client.get("/api/products")
        assert r_products.status_code == 200
        assert len(r_products.json()) > 0

        # 3. Decoy interception
        r_decoy = client.get("/admin/backup.sql")
        assert r_decoy.status_code == 200
        assert "application/x-sql" in r_decoy.headers["content-type"]
        assert "VOID DEFENSE SYSTEM - SYNTHETIC DECOY BACKUP ARTIFACT" in r_decoy.text

        # 4. Events query
        r_events = client.get("/events")
        assert r_events.status_code == 200
        events = r_events.json()
        assert len(events) >= 1
        assert events[0]["decoy_triggered"] is True

        # 5. Stats calculation
        r_stats = client.get("/stats")
        assert r_stats.status_code == 200
        stats = r_stats.json()
        assert stats["total_events"] >= 1
        assert stats["decoy_interactions"] >= 1
