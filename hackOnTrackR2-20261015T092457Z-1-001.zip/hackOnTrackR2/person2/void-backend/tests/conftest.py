"""Shared pytest fixtures and configuration for VOID test suite."""

import pytest
from app.detector import detection_engine
from app.event_logger import event_store
from app.response_engine import response_engine


@pytest.fixture(autouse=True)
def clean_system_state():
    """Ensure clean state across all tests to prevent burst/recon cross-contamination."""
    event_store.clear()
    detection_engine.reset_state()
    response_engine.clear()
    yield
    event_store.clear()
    detection_engine.reset_state()
    response_engine.clear()
