"""Quick end-to-end demo verification script."""

import json
import threading
import time
import httpx
import uvicorn

import os
import sys

# Ensure void-backend is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.main import app

def main():
    config = uvicorn.Config(app, host="127.0.0.1", port=8000, log_level="warning")
    server = uvicorn.Server(config)
    t = threading.Thread(target=server.run, daemon=True)
    t.start()
    time.sleep(1.2)

    with httpx.Client(base_url="http://127.0.0.1:8000") as client:
        print("\n--- 1. Testing GET /health ---")
        r_health = client.get("/health")
        print(f"Status: {r_health.status_code}")
        print(json.dumps(r_health.json(), indent=2))

        print("\n--- 2. Testing Legitimate GET /api/products ---")
        r_prod = client.get("/api/products")
        print(f"Status: {r_prod.status_code}, Returned items: {len(r_prod.json())}")

        print("\n--- 3. Testing Decoy GET /admin/backup.sql ---")
        r_decoy = client.get("/admin/backup.sql")
        print(f"Status: {r_decoy.status_code}")
        print(f"Header X-VOID-Interception: {r_decoy.headers.get('X-VOID-Interception')}")
        print(f"Header X-Synthetic-Artifact: {r_decoy.headers.get('X-Synthetic-Artifact')}")
        print("Body snippet:")
        print("\n".join(r_decoy.text.splitlines()[:6]))

        print("\n--- 4. Testing GET /events ---")
        r_events = client.get("/events")
        print(f"Status: {r_events.status_code}, Recorded events: {len(r_events.json())}")
        print(json.dumps(r_events.json()[0], indent=2))

        print("\n--- 5. Testing GET /stats ---")
        r_stats = client.get("/stats")
        print(f"Status: {r_stats.status_code}")
        print(json.dumps(r_stats.json(), indent=2))

    server.should_exit = True
    print("\nAll demo endpoints successfully tested!")

if __name__ == "__main__":
    main()
