# VOID — AI-Powered Cyber Defense Backend
**Person 1: Core Pipeline / Logic Engine**

VOID is an AI-powered active cyber defense backend built with Python, FastAPI, and Pydantic. It provides real-time threat detection, deceptive canary trapping, deterministic risk scoring, and operational defensive action recommendations for modern cloud applications.

---

## 1. Architecture Overview

```
                      +---------------------------------------+
                      |       Client / Attacker Request       |
                      +---------------------------------------+
                                          |
                                          v
                      +---------------------------------------+
                      |         VoidSecurityMiddleware        |
                      |   - Proxy Trust Verification          |
                      |   - Sensitive Header Redaction        |
                      |   - Path Normalization                |
                      +---------------------------------------+
                                    /           \
                                   /             \
            [Decoy Route Matched] /               \ [Normal Route]
                                 v                 v
            +---------------------------+   +---------------------------+
            |      Decoy Registry       |   |      Detection Engine     |
            |  Safe Synthetic Response  |   |  - Path Traversal (TRAV)  |
            |   (Short-circuits logic)  |   |  - SQL Injection (INJ-SQL)|
            +---------------------------+   |  - Command Injection(CMD) |
                         \                  |  - Request Burst (BURST)  |
                          \                 |  - Reconnaissance (RECON) |
                           \                +---------------------------+
                            \                             /
                             \                           /
                              v                         v
            +-----------------------------------------------------------+
            |                    Risk Scoring Engine                    |
            |   - Bounded heuristic scoring (0 - 100)                   |
            |   - Non-linear dampening (prevents inflation)             |
            |   - Session & IP risk sliding windows                     |
            +-----------------------------------------------------------+
                                          |
                                          v
            +-----------------------------------------------------------+
            |                    Unified Security Event                 |
            |                   (Pydantic SecurityEvent)                |
            +-----------------------------------------------------------+
                        /                                   \
                       v                                     v
+-------------------------------+         +-------------------------------+
|     InMemoryEventStore        |         |       Response Engine         |
|  - Thread-Safe Deque Storage  |         |  - Structured Recommendations |
|  - Verified /stats Metrics    |         |  - CONTINUE_MONITORING        |
|  - Person 3 Subscriber Hooks  |         |  - INCREASE_MONITORING        |
+-------------------------------+         |  - APPLY_RATE_LIMIT           |
                                          |  - REQUEST_TEMPORARY_BLOCK    |
                                          |  - REQUIRE_ANALYST_REVIEW     |
                                          +-------------------------------+
```

---

## 2. Directory Structure

```
void-backend/
├── app/
│   ├── __init__.py           # Package initialization & semantic versioning
│   ├── main.py               # FastAPI application, CORS, error handlers, and routes
│   ├── config.py             # Pydantic BaseSettings with environment configuration
│   ├── middleware.py         # Request interception, client IP resolution, header sanitization
│   ├── detector.py           # Modular detection engine, rule classes, risk scoring
│   ├── decoys.py             # Deception registry, path normalization, synthetic generators
│   ├── event_logger.py       # Thread-safe event store, live stats, subscriber pub/sub
│   ├── response_engine.py    # Structured defensive recommendations & audit trail
│   └── schemas.py            # Pydantic schemas (events, stats, recommendations, health)
├── tests/
│   ├── conftest.py           # Pytest fixtures and state isolation
│   ├── test_health.py        # Health endpoint & error handling tests
│   ├── test_normal_traffic.py# Legitimate traffic & header redaction tests
│   ├── test_decoys.py        # Decoy normalization & synthetic payload tests
│   ├── test_detection.py     # Rule-based detector & risk dampening tests
│   ├── test_events.py        # Telemetry queries, pagination, and subscriber tests
│   └── test_live_server.py   # Full live uvicorn server tests on port 8000
├── requirements.txt          # Python dependencies
├── .env.example              # Example environment variable configuration
├── .gitignore                # Source control ignore rules
└── README.md                 # System documentation & integration specifications
```

---

## 3. Setup and Execution

### Prerequisites
- Python 3.10+ (Tested on Python 3.14 on Windows)
- Windows PowerShell or Unix Shell

### Step 1: Create Virtual Environment
```powershell
python -m venv .venv
```

### Step 2: Activate Virtual Environment
**Windows PowerShell:**
```powershell
.\.venv\Scripts\Activate.ps1
```

**macOS / Linux:**
```bash
source .venv/bin/activate
```

### Step 3: Install Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Run Server
```powershell
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
The server will be available at `http://127.0.0.1:8000` with interactive Swagger docs at `http://127.0.0.1:8000/docs`.

---

## 4. Verification & Testing

Execute the complete automated test suite (26 passing tests):
```powershell
pytest -v
```

### Manual CLI Testing (PowerShell & curl)

#### 1. Check Service Health
```powershell
curl.exe -i http://127.0.0.1:8000/health
```

#### 2. Access Legitimate Route
```powershell
curl.exe -i http://127.0.0.1:8000/api/products
```

#### 3. Trigger Decoy Route (Deception Trap)
```powershell
curl.exe -i http://127.0.0.1:8000/admin/backup.sql
```

#### 4. Query Real-Time Security Events
```powershell
curl.exe -i "http://127.0.0.1:8000/events?limit=5"
```

#### 5. Inspect Real Aggregated Metrics
```powershell
curl.exe -i http://127.0.0.1:8000/stats
```

#### 6. Inspect Defensive Recommendations
```powershell
curl.exe -i http://127.0.0.1:8000/recommendations
```

---

## 5. API Reference & Contract Examples

### A. Health Check (`GET /health`)
```json
{
  "status": "ok",
  "version": "1.0.0",
  "uptime_seconds": 12.45,
  "timestamp": "2026-10-15T06:15:00.000000+00:00",
  "environment": "development",
  "components": {
    "detector": "active",
    "event_store": "active",
    "response_engine": "active",
    "decoys": "active"
  }
}
```

### B. Decoy Interception (`GET /admin/backup.sql`)
- **HTTP Status:** `200 OK`
- **Content-Type:** `application/x-sql; charset=utf-8`
- **Headers:** `X-Synthetic-Artifact: VOID-DECOY-DUMP-v1`, `X-VOID-Interception: DECOY_TRIGGERED`
- **Payload:** Synthetic SQL dump with canary credentials and disclaimer banners.

### C. Security Events Query (`GET /events`)
**Parameters:**
- `severity` (optional): `LOW`, `MEDIUM`, `HIGH`, `CRITICAL`
- `attack_type` (optional): `DECOY_ACCESS`, `PATH_TRAVERSAL`, `SQL_INJECTION`, `COMMAND_INJECTION`, `REQUEST_BURST`, `RECONNAISSANCE`
- `decoy_only` (optional): `true` / `false`
- `limit` (default: 50, max: 500)
- `offset` (default: 0)
- `order` (default: `desc`, options: `asc`, `desc`)

**Response:**
```json
[
  {
    "event_id": "9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d",
    "timestamp": "2026-10-15T06:15:30.123456+00:00",
    "path": "/admin/backup.sql",
    "method": "GET",
    "attack_type": "DECOY_ACCESS",
    "severity": "HIGH",
    "risk_score": 45,
    "decoy_triggered": true,
    "source_ip": "127.0.0.1",
    "reason": "Request matched configured decoy route: 'Database Backup Decoy'",
    "action": "SYNTHETIC_RESPONSE",
    "rule_ids": ["DECOY-001"],
    "evidence": [
      "Requested path: /admin/backup.sql",
      "Matched normalized decoy: /admin/backup.sql",
      "Template served: BACKUP_SQL_TEMPLATE"
    ],
    "request_id": "550e8400-e29b-41d4-a716-446655440000"
  }
]
```

### D. Verified Security Stats (`GET /stats`)
Metrics are dynamically computed from stored events without fabrication.
```json
{
  "total_events": 4,
  "severity_counts": {
    "LOW": 0,
    "MEDIUM": 1,
    "HIGH": 2,
    "CRITICAL": 1
  },
  "attack_type_counts": {
    "DECOY_ACCESS": 2,
    "REQUEST_BURST": 1,
    "SQL_INJECTION": 1
  },
  "decoy_interactions": 2,
  "unique_ips": 2,
  "aggregate_system_risk": 75,
  "highest_risk_ip": "192.168.1.100",
  "active_recommendations_count": 3,
  "generated_at": "2026-10-15T06:16:00.000000+00:00"
}
```

### E. Defensive Recommendations (`GET /recommendations`)
```json
[
  {
    "recommendation_id": "c1f72a44-8df6-48e2-b13c-097c276b9d62",
    "action_type": "REQUIRE_ANALYST_REVIEW",
    "reason": "Deception trap struck at '/admin/backup.sql'. Interaction indicates active unauthorized exploration.",
    "supporting_event_ids": ["9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d"],
    "risk_level": "HIGH",
    "human_approval_required": true,
    "expires_in_seconds": 1800,
    "target_ip": "127.0.0.1",
    "created_at": "2026-10-15T06:15:30.123456+00:00",
    "remediation_steps": [
      "Inspect decoy template telemetry logs",
      "Verify if canary credentials or tokens were saved by requester",
      "Check for subsequent requests utilizing canary tokens"
    ]
  }
]
```

---

## 6. Teammate Integration Guide

### Person 2 (Frontend Command-Center Dashboard on Port 3000)
- **CORS:** Configured by default for `http://localhost:3000` and `http://127.0.0.1:3000`.
- **Polling / Fetching:**
  - `GET /health`: Heartbeat indicator for connection status.
  - `GET /stats`: Real-time KPI cards (Total events, threat breakdown, active system risk).
  - `GET /events?limit=25`: Live stream table for intercepted incidents.
  - `GET /recommendations`: Action items requiring operator review or rate limits.

### Person 3 (Database Persistence & Webhook Notifications)

#### 1. Real-Time Event Subscription (Discord / Slack / SQLite Worker)
Person 3 does **not** need to poll the API or modify middleware. The event store exposes an event-driven pub/sub callback interface:

```python
from app.event_logger import event_store
from app.schemas import SecurityEvent

def discord_notification_listener(event: SecurityEvent) -> None:
    # Trigger alert for high and critical events
    if event.severity in ("HIGH", "CRITICAL"):
        payload = {
            "content": f":warning: **VOID Security Alert** [{event.severity}]\n"
                       f"Path: `{event.path}` | Type: `{event.attack_type}`\n"
                       f"IP: `{event.source_ip}` | Risk Score: `{event.risk_score}`\n"
                       f"Reason: {event.reason}"
        }
        # requests.post(DISCORD_WEBHOOK_URL, json=payload)

# Register the callback during app startup
event_store.register_subscriber(discord_notification_listener)
```

#### 2. Persistent Storage Extension (SQLite / PostgreSQL)
Person 3 can replace or augment `InMemoryEventStore` by subclassing `BaseEventStore` in `app/event_logger.py`:

```python
from app.event_logger import BaseEventStore
from app.schemas import SecurityEvent, SecurityStats

class SqliteEventStore(BaseEventStore):
    def __init__(self, db_path: str):
        self.db = init_db(db_path)

    def add_event(self, event: SecurityEvent) -> None:
        # INSERT INTO security_events (event_id, timestamp, path, method, ...) VALUES (...)
        pass

    def get_events(self, ...):
        # SELECT * FROM security_events WHERE ... ORDER BY timestamp DESC LIMIT ...
        pass

    def get_stats(self) -> SecurityStats:
        # SELECT COUNT(*), severity, attack_type FROM security_events ...
        pass
```

---

## 7. Security and Safety Principles

1. **Zero Secret Exposure:** Decoy routes never read `.env`, database tables, or server memory. All decoy data is generated from pure synthetic templates with explicit canary markers.
2. **Credential Sanitization:** Middleware actively strips `Authorization`, `Cookie`, `Set-Cookie`, and `X-API-Key` headers before telemetry logging.
3. **Safe Client IP Resolution:** `X-Forwarded-For` and `X-Real-IP` headers are only trusted if the immediate peer IP is explicitly listed in `TRUSTED_PROXIES` and `TRUST_PROXY_HEADERS=True`.
4. **Deterministic Bounded Scoring:** Risk scores are bounded strictly between 0 and 100 with diminishing returns to prevent false-positive inflation. Scores reflect indicator presence, not a calibrated statistical probability.
5. **Human-in-the-Loop Defense:** High-impact actions (`REQUEST_TEMPORARY_BLOCK`, `REQUIRE_ANALYST_REVIEW`) default to `human_approval_required=True` to prevent accidental operational disruption.
