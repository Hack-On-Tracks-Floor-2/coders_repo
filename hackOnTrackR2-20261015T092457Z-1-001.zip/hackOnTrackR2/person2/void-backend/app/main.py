"""Main FastAPI application for VOID Cyber Defense Backend.

Configures CORS, centralized error handling, structured logging, route interception,
legitimate demo endpoints, decoy route fallbacks, and security event queries.
"""

from contextlib import asynccontextmanager
import logging
import sys
import time
from typing import Any, AsyncGenerator, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Query, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import get_settings
from app.decoys import (
    decoy_registry,
    generate_backup_sql_response,
    generate_debug_config_response,
    generate_users_export_response,
)
from app.event_logger import event_store
from app.middleware import VoidSecurityMiddleware
from app.response_engine import response_engine
from app.schemas import (
    AttackType,
    DefensiveRecommendation,
    HealthStatus,
    Product,
    SecurityEvent,
    SecurityStats,
    SeverityLevel,
    UserProfile,
    current_utc_timestamp,
)

# Application startup timestamp
START_TIME = time.time()

# Setup structured logging
settings = get_settings()
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s (%(filename)s:%(lineno)d) - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("void.main")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifecycle management."""
    logger.info("VOID Cyber Defense Backend starting up on port %d...", settings.port)
    logger.info("CORS enabled for origins: %s", settings.cors_origins)
    yield
    logger.info("VOID Cyber Defense Backend shutting down cleanly.")


app = FastAPI(
    title="VOID — Cyber Defense Backend",
    description="AI-powered Cyber Defense System core pipeline, deception engine, and detection logic.",
    version="1.0.0",
    lifespan=lifespan,
)

# 1. Configure CORS for frontend command-center (port 3000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 2. Add VOID Security Interception Middleware
app.add_middleware(VoidSecurityMiddleware)


# Centralized Exception Handlers
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    """Consistent JSON formatting for standard HTTP exceptions."""
    request_id = getattr(request.state, "request_id", "unknown")
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": "HTTP Exception",
            "detail": exc.detail,
            "status_code": exc.status_code,
            "request_id": request_id,
            "timestamp": current_utc_timestamp(),
        },
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    """Consistent JSON formatting for request payload validation errors."""
    request_id = getattr(request.state, "request_id", "unknown")
    return JSONResponse(
        status_code=422,
        content={
            "error": "Validation Error",
            "detail": exc.errors(),
            "status_code": 422,
            "request_id": request_id,
            "timestamp": current_utc_timestamp(),
        },
    )


@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Centralized fallback for unhandled exceptions, masking raw traces from clients."""
    request_id = getattr(request.state, "request_id", "unknown")
    logger.error("Unhandled exception for request %s: %s", request_id, str(exc), exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "Internal Server Error",
            "detail": "An unexpected error occurred while processing the request.",
            "status_code": 500,
            "request_id": request_id,
            "timestamp": current_utc_timestamp(),
        },
    )


# System & Telemetry Endpoints
@app.get(
    "/health",
    response_model=HealthStatus,
    tags=["System"],
    summary="Service Health Check",
)
async def health_check() -> HealthStatus:
    """Return backend service status, version, uptime, and subsystem health."""
    uptime = time.time() - START_TIME
    return HealthStatus(
        status="ok",
        version="1.0.0",
        uptime_seconds=round(uptime, 2),
        timestamp=current_utc_timestamp(),
        environment=settings.environment,
        components={
            "detector": "active",
            "event_store": "active",
            "response_engine": "active",
            "decoys": "active",
        },
    )


@app.get(
    "/events",
    response_model=List[SecurityEvent],
    tags=["Security Telemetry"],
    summary="Query Security Events",
)
async def get_events(
    severity: Optional[SeverityLevel] = Query(None, description="Filter by severity level"),
    attack_type: Optional[AttackType] = Query(None, description="Filter by attack classification"),
    decoy_only: Optional[bool] = Query(None, description="Filter exclusively for decoy interactions"),
    limit: int = Query(50, ge=1, le=500, description="Maximum number of events to return"),
    offset: int = Query(0, ge=0, description="Offset for pagination"),
    order: str = Query("desc", pattern="^(asc|desc)$", description="Sort order (desc=newest first)"),
) -> List[SecurityEvent]:
    """Retrieve filtered, paginated security events from the event store."""
    return event_store.get_events(
        severity=severity,
        attack_type=attack_type,
        decoy_triggered=decoy_only,
        limit=limit,
        offset=offset,
        reverse_chronological=(order == "desc"),
    )


@app.get(
    "/stats",
    response_model=SecurityStats,
    tags=["Security Telemetry"],
    summary="Aggregated Security Metrics",
)
async def get_stats() -> SecurityStats:
    """Return live security metrics calculated deterministically from stored events."""
    return event_store.get_stats()


@app.get(
    "/recommendations",
    response_model=List[DefensiveRecommendation],
    tags=["Defensive Actions"],
    summary="Defensive Action Recommendations",
)
async def get_recommendations(
    limit: int = Query(50, ge=1, le=200, description="Maximum recommendations to fetch")
) -> List[DefensiveRecommendation]:
    """Fetch recent defensive recommendations formulated by the response engine."""
    return response_engine.get_active_recommendations(limit=limit)


# Legitimate Demo Endpoints
DEMO_PRODUCTS: List[Product] = [
    Product(
        id=1,
        name="VOID Sentinel Quantum Key",
        category="Hardware Security",
        price=349.99,
        stock=42,
        description="Hardware-enforced cryptographic security key with zero-trust attestation.",
    ),
    Product(
        id=2,
        name="Adaptive Perimeter Shield",
        category="Network Protection",
        price=1299.00,
        stock=15,
        description="Next-gen dynamic firewall with automated anomaly dampening.",
    ),
    Product(
        id=3,
        name="Canary Core Sensor Pack",
        category="Deception Tech",
        price=599.50,
        stock=30,
        description="Multi-protocol decoy trap array for early reconnaissance trapping.",
    ),
    Product(
        id=4,
        name="Mesh VPN Cryptographic Gateway",
        category="Secure Access",
        price=850.00,
        stock=8,
        description="High-throughput point-to-point WireGuard encrypted tunnel gateway.",
    ),
    Product(
        id=5,
        name="Auditor Pro Log Ingestor",
        category="SIEM / Analytics",
        price=420.00,
        stock=100,
        description="Immutable append-only security log ingestion agent.",
    ),
]


@app.get(
    "/api/products",
    response_model=List[Product],
    tags=["Demo Application"],
    summary="Legitimate Products Catalog",
)
async def list_products(
    category: Optional[str] = Query(None, description="Optional category filter")
) -> List[Product]:
    """Legitimate business endpoint returning product catalog items."""
    if category:
        return [p for p in DEMO_PRODUCTS if p.category.lower() == category.lower()]
    return DEMO_PRODUCTS


@app.get(
    "/api/profile",
    response_model=UserProfile,
    tags=["Demo Application"],
    summary="Legitimate User Profile",
)
async def get_user_profile() -> UserProfile:
    """Legitimate demo endpoint returning authenticated operator profile."""
    return UserProfile(
        id="USR-PROD-7710",
        username="alex_secops",
        email="alex.operator@defense-grid.corp",
        role="Senior Defense Analyst",
        tier="Enterprise SecOps",
        created_at="2026-01-10T12:00:00Z",
    )


# Explicit Decoy Endpoints (Handled by middleware, defined here for routing fallback and docs)
@app.get(
    "/admin/backup.sql",
    tags=["Decoys"],
    summary="Database Backup Decoy",
    include_in_schema=True,
)
async def decoy_backup_sql():
    """Decoy endpoint enticing unauthorized database extraction.

    Returns synthetic data only.
    """
    return generate_backup_sql_response()


@app.get(
    "/api/v1/internal/users/export",
    tags=["Decoys"],
    summary="Internal Users Export Decoy",
    include_in_schema=True,
)
async def decoy_users_export():
    """Decoy endpoint trapping privileged lateral directory enumeration.

    Returns synthetic data only.
    """
    return generate_users_export_response()


@app.get(
    "/api/debug/config",
    tags=["Decoys"],
    summary="Debug Configuration Decoy",
    include_in_schema=True,
)
async def decoy_debug_config():
    """Decoy endpoint trapping sensitive configuration exposure probes.

    Returns synthetic data only.
    """
    return generate_debug_config_response()
