"""Detection engine and deterministic risk scoring for VOID Cyber Defense Backend.

Implements modular rule-based inspection for decoy access, path traversal,
SQL injection, command injection, request bursts, and reconnaissance activity.
Includes a transparent, bounded risk-scoring algorithm with score dampening.
"""

from abc import ABC, abstractmethod
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
import re
import threading
import time
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import unquote

from app.config import get_settings
from app.decoys import decoy_registry, normalize_request_path
from app.schemas import AttackType, SeverityLevel, current_utc_timestamp


@dataclass
class DetectionResult:
    """Individual rule detection finding."""

    rule_id: str
    attack_type: AttackType
    severity: SeverityLevel
    score_contribution: int
    explanation: str
    evidence: List[str]
    timestamp: str = field(default_factory=current_utc_timestamp)


class BaseDetectionRule(ABC):
    """Abstract base class for all detection rules."""

    @property
    @abstractmethod
    def rule_id(self) -> str:
        """Unique identifier for this rule."""
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Descriptive name for this rule."""
        pass

    @abstractmethod
    def evaluate(
        self,
        method: str,
        path: str,
        normalized_path: str,
        query_params: Dict[str, str],
        client_ip: str,
        headers: Dict[str, str],
    ) -> Optional[DetectionResult]:
        """Evaluate request context and return DetectionResult if triggered."""
        pass


class DecoyAccessRule(BaseDetectionRule):
    """Detects requests directly targeting configured deception decoy routes."""

    @property
    def rule_id(self) -> str:
        return "DECOY-001"

    @property
    def name(self) -> str:
        return "Decoy Trap Triggered"

    def evaluate(
        self,
        method: str,
        path: str,
        normalized_path: str,
        query_params: Dict[str, str],
        client_ip: str,
        headers: Dict[str, str],
    ) -> Optional[DetectionResult]:
        decoy = decoy_registry.get_decoy(normalized_path)
        if decoy:
            return DetectionResult(
                rule_id=self.rule_id,
                attack_type=AttackType.DECOY_ACCESS,
                severity=SeverityLevel.HIGH,
                score_contribution=45,
                explanation=f"Request targeted decoy endpoint '{decoy.name}' ({decoy.template_id})",
                evidence=[
                    f"Requested path: {path}",
                    f"Matched normalized decoy: {decoy.path}",
                    f"Template served: {decoy.template_id}",
                ],
            )
        return None


class PathTraversalRule(BaseDetectionRule):
    """Detects path traversal indicators (e.g. ../, ..\\, /etc/passwd, boot.ini)."""

    def __init__(self) -> None:
        self._patterns = [
            (re.compile(r"(?:\.\./|\.\.\\)", re.IGNORECASE), "Directory dot-dot traversal sequence"),
            (re.compile(r"(?:%2e%2e%2f|%2e%2e/|\.\.%2f|%2e%2e%5c)", re.IGNORECASE), "Encoded path traversal sequence"),
            (re.compile(r"/etc/(?:passwd|shadow|hosts|group)", re.IGNORECASE), "Linux sensitive system file path"),
            (re.compile(r"(?:win\.ini|boot\.ini|windows/system32|windows\\system32)", re.IGNORECASE), "Windows sensitive system file path"),
            (re.compile(r"%00|\x00", re.IGNORECASE), "Null byte injection attempt"),
        ]

    @property
    def rule_id(self) -> str:
        return "TRAV-001"

    @property
    def name(self) -> str:
        return "Path Traversal Indicator"

    def evaluate(
        self,
        method: str,
        path: str,
        normalized_path: str,
        query_params: Dict[str, str],
        client_ip: str,
        headers: Dict[str, str],
    ) -> Optional[DetectionResult]:
        targets_to_inspect = [path, unquote(path)]
        for k, v in query_params.items():
            targets_to_inspect.append(f"{k}={v}")
            targets_to_inspect.append(unquote(f"{k}={v}"))

        matched_evidence = []
        for target in targets_to_inspect:
            for pattern, desc in self._patterns:
                match = pattern.search(target)
                if match:
                    matched_evidence.append(f"{desc}: '{match.group(0)}' in string segment")

        if matched_evidence:
            return DetectionResult(
                rule_id=self.rule_id,
                attack_type=AttackType.PATH_TRAVERSAL,
                severity=SeverityLevel.HIGH,
                score_contribution=40,
                explanation="Detected path traversal or local file inclusion indicator in request",
                evidence=list(set(matched_evidence))[:4],
            )
        return None


class SqlInjectionRule(BaseDetectionRule):
    """Detects common SQL injection indicators in URL paths and query parameters."""

    def __init__(self) -> None:
        self._patterns = [
            (re.compile(r"\bUNION\s+(?:ALL\s+)?SELECT\b", re.IGNORECASE), "SQL UNION SELECT injection"),
            (re.compile(r"'\s*OR\s+['\"]?1['\"]?\s*=\s*['\"]?1", re.IGNORECASE), "SQL tautology boolean injection (' OR 1=1)"),
            (re.compile(r"\"\s*OR\s+[\"']?1[\"']?\s*=\s*[\"']?1", re.IGNORECASE), 'SQL tautology boolean injection (" OR 1=1)'),
            (re.compile(r"\bOR\s+1\s*=\s*1\b", re.IGNORECASE), "Unquoted tautology boolean injection (OR 1=1)"),
            (re.compile(r";\s*DROP\s+TABLE\b", re.IGNORECASE), "Destructive SQL statement termination (; DROP TABLE)"),
            (re.compile(r"--\s+|\/\*.*\*\/", re.IGNORECASE), "SQL comment injection sequence"),
            (re.compile(r"\bSLEEP\s*\(\s*\d+\s*\)", re.IGNORECASE), "Time-based blind SQL injection (SLEEP)"),
            (re.compile(r"\bBENCHMARK\s*\(", re.IGNORECASE), "Resource-exhaustion blind SQL injection (BENCHMARK)"),
            (re.compile(r"\bxp_cmdshell\b", re.IGNORECASE), "MSSQL command execution procedure (xp_cmdshell)"),
        ]

    @property
    def rule_id(self) -> str:
        return "INJ-SQL-001"

    @property
    def name(self) -> str:
        return "SQL Injection Indicator"

    def evaluate(
        self,
        method: str,
        path: str,
        normalized_path: str,
        query_params: Dict[str, str],
        client_ip: str,
        headers: Dict[str, str],
    ) -> Optional[DetectionResult]:
        targets = [path, unquote(path)]
        for k, v in query_params.items():
            targets.append(f"{k}={v}")
            targets.append(unquote(f"{k}={v}"))

        evidence = []
        for target in targets:
            for pattern, desc in self._patterns:
                match = pattern.search(target)
                if match:
                    evidence.append(f"{desc}: matched '{match.group(0)}'")

        if evidence:
            return DetectionResult(
                rule_id=self.rule_id,
                attack_type=AttackType.SQL_INJECTION,
                severity=SeverityLevel.HIGH,
                score_contribution=40,
                explanation="Pattern matching known SQL injection syntax identified in input parameters",
                evidence=list(set(evidence))[:4],
            )
        return None


class CommandInjectionRule(BaseDetectionRule):
    """Detects command injection indicators in request paths and parameters."""

    def __init__(self) -> None:
        self._patterns = [
            (
                re.compile(r";\s*(?:cat|ls|whoami|id|uname|curl|wget|dir|net\s+user|powershell|cmd)\b", re.IGNORECASE),
                "Chained shell command separator (; <cmd>)",
            ),
            (
                re.compile(r"\|\s*(?:cat|ls|whoami|id|uname|curl|wget|dir|powershell|cmd)\b", re.IGNORECASE),
                "Piped shell command ( | <cmd>)",
            ),
            (
                re.compile(r"&&\s*(?:cat|ls|whoami|id|uname|curl|wget|dir|powershell|cmd)\b", re.IGNORECASE),
                "Conditional command execution ( && <cmd>)",
            ),
            (
                re.compile(r"\$\((?:whoami|id|uname)\)|`whoami`", re.IGNORECASE),
                "Command substitution syntax ($(...) or `...`)",
            ),
            (
                re.compile(r"\$\{IFS\}", re.IGNORECASE),
                "Shell environment variable whitespace bypass (${IFS})",
            ),
        ]

    @property
    def rule_id(self) -> str:
        return "INJ-CMD-001"

    @property
    def name(self) -> str:
        return "Command Injection Indicator"

    def evaluate(
        self,
        method: str,
        path: str,
        normalized_path: str,
        query_params: Dict[str, str],
        client_ip: str,
        headers: Dict[str, str],
    ) -> Optional[DetectionResult]:
        targets = [path, unquote(path)]
        for k, v in query_params.items():
            targets.append(f"{k}={v}")
            targets.append(unquote(f"{k}={v}"))

        evidence = []
        for target in targets:
            for pattern, desc in self._patterns:
                match = pattern.search(target)
                if match:
                    evidence.append(f"{desc}: matched '{match.group(0)}'")

        if evidence:
            return DetectionResult(
                rule_id=self.rule_id,
                attack_type=AttackType.COMMAND_INJECTION,
                severity=SeverityLevel.HIGH,
                score_contribution=40,
                explanation="Pattern matching OS shell command execution syntax identified",
                evidence=list(set(evidence))[:4],
            )
        return None


class RequestBurstRule(BaseDetectionRule):
    """Detects request bursts exceeding rate thresholds within a sliding time window."""

    def __init__(self, threshold: Optional[int] = None, window_seconds: Optional[float] = None) -> None:
        self._lock = threading.Lock()
        self._history: Dict[str, deque] = defaultdict(deque)
        self._threshold = threshold
        self._window_seconds = window_seconds

    @property
    def rule_id(self) -> str:
        return "BURST-001"

    @property
    def name(self) -> str:
        return "Suspicious Request Burst"

    def _get_thresholds(self) -> Tuple[int, float]:
        settings = get_settings()
        thresh = self._threshold if self._threshold is not None else settings.burst_threshold
        win = self._window_seconds if self._window_seconds is not None else settings.burst_window_seconds
        return thresh, win

    def evaluate(
        self,
        method: str,
        path: str,
        normalized_path: str,
        query_params: Dict[str, str],
        client_ip: str,
        headers: Dict[str, str],
    ) -> Optional[DetectionResult]:
        thresh, win = self._get_thresholds()
        now = time.time()

        with self._lock:
            q = self._history[client_ip]
            # Prune old timestamps
            while q and (now - q[0]) > win:
                q.popleft()

            # Record current request
            q.append(now)
            current_count = len(q)

        if current_count >= thresh:
            return DetectionResult(
                rule_id=self.rule_id,
                attack_type=AttackType.REQUEST_BURST,
                severity=SeverityLevel.MEDIUM,
                score_contribution=25,
                explanation=f"High frequency request burst detected: {current_count} requests in {win:.1f}s window",
                evidence=[
                    f"Burst count: {current_count} requests",
                    f"Threshold: {thresh} requests per {win:.1f}s window",
                    f"Source IP: {client_ip}",
                ],
            )
        return None

    def reset(self) -> None:
        """Reset internal history for deterministic testing."""
        with self._lock:
            self._history.clear()


class ReconnaissanceRule(BaseDetectionRule):
    """Detects reconnaissance scanning patterns across multiple sensitive or unusual endpoints."""

    def __init__(self, threshold: Optional[int] = None, window_seconds: Optional[float] = None) -> None:
        self._lock = threading.Lock()
        self._history: Dict[str, deque] = defaultdict(deque)
        self._threshold = threshold
        self._window_seconds = window_seconds
        self._sensitive_indicators = {
            ".env",
            ".git",
            "wp-admin",
            "phpinfo",
            "actuator",
            "swagger",
            "phpmyadmin",
            "server-status",
            "backup.sql",
            "internal/users/export",
            "debug/config",
            "config.json",
            "id_rsa",
        }

    @property
    def rule_id(self) -> str:
        return "RECON-001"

    @property
    def name(self) -> str:
        return "Reconnaissance Scan Pattern"

    def _get_thresholds(self) -> Tuple[int, float]:
        settings = get_settings()
        thresh = self._threshold if self._threshold is not None else settings.recon_threshold
        win = self._window_seconds if self._window_seconds is not None else settings.recon_window_seconds
        return thresh, win

    def _is_recon_target(self, normalized_path: str) -> bool:
        if decoy_registry.is_decoy(normalized_path):
            return True
        path_lower = normalized_path.lower()
        return any(indicator in path_lower for indicator in self._sensitive_indicators)

    def evaluate(
        self,
        method: str,
        path: str,
        normalized_path: str,
        query_params: Dict[str, str],
        client_ip: str,
        headers: Dict[str, str],
    ) -> Optional[DetectionResult]:
        if not self._is_recon_target(normalized_path):
            return None

        thresh, win = self._get_thresholds()
        now = time.time()

        with self._lock:
            q = self._history[client_ip]
            while q and (now - q[0][0]) > win:
                q.popleft()

            q.append((now, normalized_path))
            unique_paths = {p for _, p in q}

        if len(unique_paths) >= thresh:
            return DetectionResult(
                rule_id=self.rule_id,
                attack_type=AttackType.RECONNAISSANCE,
                severity=SeverityLevel.HIGH,
                score_contribution=35,
                explanation=f"Reconnaissance sweep detected: {len(unique_paths)} unique sensitive endpoints probed within {win:.1f}s",
                evidence=[
                    f"Probed sensitive paths: {sorted(list(unique_paths))}",
                    f"Threshold: {thresh} endpoints in {win:.1f}s window",
                ],
            )
        return None

    def reset(self) -> None:
        """Reset internal history for deterministic testing."""
        with self._lock:
            self._history.clear()


class RiskScoringEngine:
    """Deterministic, bounded risk-scoring engine.

    Calculates individual-request and cumulative-session threat scores
    from 0 to 100 with diminishing returns to prevent uncontrolled inflation.
    Note: Heuristic score reflecting indicator presence, not a calibrated statistical probability.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._ip_history: Dict[str, deque] = defaultdict(deque)

    def calculate_event_score(self, findings: List[DetectionResult]) -> Tuple[int, SeverityLevel, str]:
        """Compute bounded risk score (0-100) and severity for a single set of detection findings."""
        if not findings:
            return 0, SeverityLevel.LOW, "Normal application traffic"

        # Sort findings descending by score contribution
        sorted_findings = sorted(findings, key=lambda f: f.score_contribution, reverse=True)
        primary = sorted_findings[0]

        # Base score is primary finding's contribution
        calculated_score = float(primary.score_contribution)

        # Additional findings contribute with dampening factor (0.35)
        for additional in sorted_findings[1:]:
            calculated_score += additional.score_contribution * 0.35

        # Strictly clamp between 0 and 100
        final_score = int(min(100.0, max(0.0, round(calculated_score))))

        # Map score to SeverityLevel
        if final_score >= 80:
            severity = SeverityLevel.CRITICAL
        elif final_score >= 50:
            severity = SeverityLevel.HIGH
        elif final_score >= 25:
            severity = SeverityLevel.MEDIUM
        else:
            severity = SeverityLevel.LOW

        reasons = [f"{f.rule_id}: {f.explanation}" for f in sorted_findings]
        explanation = " | ".join(reasons)

        return final_score, severity, explanation

    def update_ip_risk(self, client_ip: str, event_score: int) -> int:
        """Track and calculate aggregate session risk for an IP with sliding-window decay."""
        now = time.time()
        window_seconds = 600.0  # 10 minutes session window

        with self._lock:
            history = self._ip_history[client_ip]
            while history and (now - history[0][0]) > window_seconds:
                history.popleft()

            history.append((now, event_score))

            if not history:
                return 0

            # Session score computation with diminishing returns:
            # highest event + 20% of other events in window
            scores = [score for _, score in history]
            scores_sorted = sorted(scores, reverse=True)
            aggregate = scores_sorted[0]
            for extra in scores_sorted[1:]:
                aggregate += extra * 0.20

            final_session_score = int(min(100.0, max(0.0, round(aggregate))))
            return final_session_score

    def get_aggregate_system_risk(self) -> int:
        """Return overall system risk based on recent IP activity."""
        now = time.time()
        with self._lock:
            all_recent_scores = []
            for ip, hist in self._ip_history.items():
                recent = [s for t, s in hist if (now - t) <= 600.0]
                if recent:
                    all_recent_scores.append(max(recent))

            if not all_recent_scores:
                return 0
            # System risk is peak recent risk bounded at 100
            return min(100, max(all_recent_scores))

    def get_highest_risk_ip(self) -> Optional[str]:
        """Return the IP currently holding the highest recent risk score."""
        now = time.time()
        highest_score = -1
        highest_ip = None

        with self._lock:
            for ip, hist in self._ip_history.items():
                recent = [s for t, s in hist if (now - t) <= 600.0]
                if recent:
                    m = max(recent)
                    if m > highest_score:
                        highest_score = m
                        highest_ip = ip

        return highest_ip if highest_score > 0 else None

    def reset(self) -> None:
        """Reset scoring engine history."""
        with self._lock:
            self._ip_history.clear()


class DetectionEngine:
    """Central modular detection engine coordinating all inspection rules."""

    def __init__(self) -> None:
        self._rules: List[BaseDetectionRule] = []
        self._burst_rule = RequestBurstRule()
        self._recon_rule = ReconnaissanceRule()
        self._register_default_rules()
        self.risk_scorer = RiskScoringEngine()

    def _register_default_rules(self) -> None:
        self.add_rule(DecoyAccessRule())
        self.add_rule(PathTraversalRule())
        self.add_rule(SqlInjectionRule())
        self.add_rule(CommandInjectionRule())
        self.add_rule(self._burst_rule)
        self.add_rule(self._recon_rule)

    def add_rule(self, rule: BaseDetectionRule) -> None:
        """Register a new modular detection rule."""
        self._rules.append(rule)

    def evaluate_request(
        self,
        method: str,
        path: str,
        query_params: Optional[Dict[str, str]] = None,
        client_ip: str = "127.0.0.1",
        headers: Optional[Dict[str, str]] = None,
    ) -> List[DetectionResult]:
        """Execute all detection rules against the incoming request."""
        query_params = query_params or {}
        headers = headers or {}
        normalized_path = normalize_request_path(path)

        findings: List[DetectionResult] = []
        for rule in self._rules:
            try:
                res = rule.evaluate(
                    method=method,
                    path=path,
                    normalized_path=normalized_path,
                    query_params=query_params,
                    client_ip=client_ip,
                    headers=headers,
                )
                if res:
                    findings.append(res)
            except Exception:
                # Keep engine resilient; rule errors must not crash request handling
                continue

        return findings

    def reset_state(self) -> None:
        """Reset stateful rules and risk scorer for automated testing."""
        self._burst_rule.reset()
        self._recon_rule.reset()
        self.risk_scorer.reset()


# Global singleton detection engine
detection_engine = DetectionEngine()
