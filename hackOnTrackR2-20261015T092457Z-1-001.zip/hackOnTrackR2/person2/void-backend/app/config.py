"""Application configuration module for VOID Cyber Defense Backend.

Manages runtime settings through environment variables with safe defaults.
"""

from functools import lru_cache
from typing import List
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """VOID backend runtime configuration settings."""

    # Server settings
    host: str = Field(default="127.0.0.1", description="Server bind host")
    port: int = Field(default=8000, description="Server bind port")
    environment: str = Field(default="development", description="Environment name")
    log_level: str = Field(default="INFO", description="Standard logging level")

    # Security & CORS
    cors_origins: List[str] = Field(
        default=["http://localhost:3000", "http://127.0.0.1:3000"],
        description="Allowed CORS origins for the frontend dashboard",
    )
    trusted_proxies: List[str] = Field(
        default=[],
        description="List of trusted upstream reverse proxy IP addresses",
    )
    trust_proxy_headers: bool = Field(
        default=False,
        description="Whether to trust X-Forwarded-For headers when not behind trusted proxy",
    )

    # Detection Engine Thresholds
    burst_threshold: int = Field(
        default=5,
        description="Number of requests within time window to trigger burst detection",
    )
    burst_window_seconds: float = Field(
        default=10.0,
        description="Sliding window duration in seconds for burst detection",
    )
    recon_threshold: int = Field(
        default=3,
        description="Distinct sensitive or decoy paths accessed before triggering reconnaissance rule",
    )
    recon_window_seconds: float = Field(
        default=30.0,
        description="Time window in seconds for tracking reconnaissance activity",
    )

    # Event Store
    max_stored_events: int = Field(
        default=1000,
        description="Maximum number of events retained in memory before rotating",
    )

    # Defensive Action Policies
    auto_enforce_actions: bool = Field(
        default=False,
        description="Whether defensive actions are automatically enforced (opt-in sandbox only)",
    )

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


@lru_cache()
def get_settings() -> Settings:
    """Return a cached instance of the application settings."""
    return Settings()
