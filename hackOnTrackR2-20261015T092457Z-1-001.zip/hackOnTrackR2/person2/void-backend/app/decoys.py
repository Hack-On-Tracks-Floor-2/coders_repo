"""Decoy configuration, route normalization, and safe synthetic response generator.

Ensures deceptive traps never execute real backend business logic, never expose real
secrets or databases, and always return realistic synthetic responses.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
import posixpath
from typing import Any, Callable, Dict, Optional
import urllib.parse
from fastapi.responses import JSONResponse, PlainTextResponse, Response


def normalize_request_path(path: str) -> str:
    """Normalize a request URL path safely without bypass vulnerabilities.

    - Strips query string and fragments if present.
    - Decodes percent-encoded characters.
    - Eliminates duplicate consecutive slashes (`//` -> `/`).
    - Resolves relative path segments (`.` and `..`) safely using posixpath.normpath.
    - Preserves leading slash.
    - Strips trailing slash unless root `/`.
    """
    if not path:
        return "/"

    # Strip query and fragment
    parsed = urllib.parse.urlsplit(path)
    clean_path = parsed.path

    # URL-decode safely
    try:
        decoded_path = urllib.parse.unquote(clean_path)
    except Exception:
        decoded_path = clean_path

    # Standardize slash direction
    standardized = decoded_path.replace("\\", "/")

    # Normalize dot segments without leaving root
    # posixpath.normpath resolves '.' and '..'
    normalized = posixpath.normpath(standardized)

    # Ensure starts with /
    if not normalized.startswith("/"):
        normalized = "/" + normalized

    # Remove trailing slash unless root
    if len(normalized) > 1 and normalized.endswith("/"):
        normalized = normalized[:-1]

    return normalized


@dataclass(frozen=True)
class DecoyRoute:
    """Specification for an active decoy endpoint."""

    path: str
    name: str
    description: str
    template_id: str
    content_type: str
    status_code: int = 200
    headers: Dict[str, str] = field(default_factory=dict)
    generator: Optional[Callable[[], Response]] = None


# Synthetic Data Generators (Purely Fabricated Data)

def generate_backup_sql_response() -> Response:
    """Fabricated SQL database backup dump containing only synthetic records."""
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    sql_content = f"""-- ========================================================
-- VOID DEFENSE SYSTEM - SYNTHETIC DECOY BACKUP ARTIFACT
-- GENERATED: {timestamp}
-- NOTICE: FABRICATED DATA FOR DECEPTION PURPOSES ONLY.
-- CONTAINS ZERO PRODUCTION RECORDS OR REAL CREDENTIALS.
-- ========================================================

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `auth_credentials_archive`;
CREATE TABLE `auth_credentials_archive` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `email_address` varchar(128) NOT NULL,
  `api_key_hash` varchar(128) NOT NULL,
  `role_permission` varchar(32) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `auth_credentials_archive` WRITE;
INSERT INTO `auth_credentials_archive` VALUES
(101,'synthetic_corp_admin','admin.demo@internal-synthetic.corp','$2b$12$eX4mpL3SyNthEt1cH4shNotR3aL0000000000000000000000000','GLOBAL_SYSADMIN','2025-01-15 08:30:00'),
(102,'mock_financial_auditor','auditor.demo@internal-synthetic.corp','$2b$12$f4k3SyNthEt1cH4shNotR3aL00000000000000000000000000000','FIN_READONLY','2025-02-01 11:15:22'),
(103,'devops_staging_lead','deploy.demo@internal-synthetic.corp','$2b$12$dUmMySyNthEt1cH4shNotR3aL00000000000000000000000000000','INFRA_ADMIN','2025-03-10 14:02:45');
UNLOCK TABLES;

-- Dump completed on {timestamp}
"""
    return PlainTextResponse(
        content=sql_content,
        status_code=200,
        headers={
            "Content-Type": "application/x-sql; charset=utf-8",
            "Content-Disposition": 'attachment; filename="backup_2026_q1.sql"',
            "X-Synthetic-Artifact": "VOID-DECOY-DUMP-v1",
        },
    )


def generate_users_export_response() -> Response:
    """Fabricated internal user directory export with synthetic profiles."""
    payload = {
        "export_metadata": {
            "status": "COMPLETED",
            "archive_format": "INTERNAL_V2",
            "record_count": 3,
            "generated_utc": datetime.now(timezone.utc).isoformat(),
            "synthetic_disclaimer": "VOID Synthetic Canary Dataset - Not real identity records",
        },
        "users": [
            {
                "id": "USR-SYNTH-9021",
                "employee_code": "EMP-9021",
                "full_name": "Marcus Vance",
                "email": "marcus.vance@synthetic-corp-node.internal",
                "department": "Core Infrastructure",
                "clearance_level": "RESTRICTED",
                "synthetic_token_canary": "CANARY_TOKEN_7b8a1c90_DECOY",
            },
            {
                "id": "USR-SYNTH-9022",
                "employee_code": "EMP-9022",
                "full_name": "Elena Rostova",
                "email": "elena.rostova@synthetic-corp-node.internal",
                "department": "Treasury Operations",
                "clearance_level": "SECRET",
                "synthetic_token_canary": "CANARY_TOKEN_91d4e2f3_DECOY",
            },
            {
                "id": "USR-SYNTH-9023",
                "employee_code": "EMP-9023",
                "full_name": "Devin Thorne",
                "email": "devin.thorne@synthetic-corp-node.internal",
                "department": "Security Architecture",
                "clearance_level": "TOP_SECRET",
                "synthetic_token_canary": "CANARY_TOKEN_44a6c8e1_DECOY",
            },
        ],
    }
    return JSONResponse(
        content=payload,
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "X-Synthetic-Artifact": "VOID-USER-EXPORT-v1",
        },
    )


def generate_debug_config_response() -> Response:
    """Fabricated debug configuration with fictional parameters."""
    payload = {
        "service": "void-internal-config-service",
        "environment": "staging-sandbox-demo",
        "debug_mode": True,
        "build_version": "v3.12.0-canary-test",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "cluster_info": {
            "node_count": 4,
            "active_region": "us-east-demo-zone",
            "orchestrator": "kubernetes-synthetic.corp.local",
            "upstream_gateway": "http://10.244.1.100:8080",
        },
        "feature_flags": {
            "canary_routing_enabled": True,
            "mock_telemetry_stream": True,
            "enforce_mfa_override": False,
        },
        "synthetic_notice": "Purely synthetic test values. No real environment variables or secrets exposed.",
    }
    return JSONResponse(
        content=payload,
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "X-Synthetic-Artifact": "VOID-DEBUG-CONFIG-v1",
        },
    )


class DecoyRegistry:
    """Extensible registry of decoy routes."""

    def __init__(self) -> None:
        self._routes: Dict[str, DecoyRoute] = {}
        self._register_default_decoys()

    def _register_default_decoys(self) -> None:
        """Register the default decoy endpoints mandated by specifications."""
        self.register(
            DecoyRoute(
                path="/admin/backup.sql",
                name="Database Backup Decoy",
                description="Simulated database backup archive enticing unauthorized data acquisition",
                template_id="BACKUP_SQL_TEMPLATE",
                content_type="application/x-sql",
                generator=generate_backup_sql_response,
            )
        )
        self.register(
            DecoyRoute(
                path="/api/v1/internal/users/export",
                name="Internal Users Export Decoy",
                description="Simulated privileged user export endpoint capturing lateral movement",
                template_id="USERS_EXPORT_JSON_TEMPLATE",
                content_type="application/json",
                generator=generate_users_export_response,
            )
        )
        self.register(
            DecoyRoute(
                path="/api/debug/config",
                name="Debug Configuration Decoy",
                description="Simulated sensitive runtime debug configuration endpoint",
                template_id="DEBUG_CONFIG_JSON_TEMPLATE",
                content_type="application/json",
                generator=generate_debug_config_response,
            )
        )

    def register(self, decoy: DecoyRoute) -> None:
        """Add or update a decoy route in the registry."""
        normalized_path = normalize_request_path(decoy.path)
        self._routes[normalized_path] = decoy

    def get_decoy(self, raw_path: str) -> Optional[DecoyRoute]:
        """Look up a decoy route by exact normalized path matching.

        Avoids fragile substring checks and ambiguous path parsing.
        """
        norm_path = normalize_request_path(raw_path)
        return self._routes.get(norm_path)

    def is_decoy(self, raw_path: str) -> bool:
        """Check whether the given path resolves to an active decoy."""
        return self.get_decoy(raw_path) is not None

    def list_routes(self) -> Dict[str, DecoyRoute]:
        """Return a copy of registered decoy routes."""
        return dict(self._routes)


# Global singleton decoy registry
decoy_registry = DecoyRegistry()
