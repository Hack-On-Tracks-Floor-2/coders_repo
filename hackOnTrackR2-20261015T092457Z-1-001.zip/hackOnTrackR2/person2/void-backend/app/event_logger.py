"""Event logging, in-memory event store, and subscriber integration interface for VOID.

Provides thread-safe storage, dynamic metric calculation, filtering, pagination,
and a clean extension interface for Person 3's persistence and webhook notifications.
"""

from abc import ABC, abstractmethod
from collections import Counter, deque
import logging
import threading
from typing import Any, Callable, Dict, List, Optional

from app.config import get_settings
from app.schemas import AttackType, SecurityEvent, SecurityStats, SeverityLevel

logger = logging.getLogger("void.event_logger")


class BaseEventStore(ABC):
    """Abstract interface defining required event storage capabilities.

    Person 3 can inherit from this class to implement SQLite or PostgreSQL persistence
    without modifying existing routing, detection, or presentation logic.
    """

    @abstractmethod
    def add_event(self, event: SecurityEvent) -> None:
        """Persist or record a new security event."""
        pass

    @abstractmethod
    def get_events(
        self,
        severity: Optional[SeverityLevel] = None,
        attack_type: Optional[AttackType] = None,
        decoy_triggered: Optional[bool] = None,
        limit: int = 50,
        offset: int = 0,
        reverse_chronological: bool = True,
    ) -> List[SecurityEvent]:
        """Query stored events with filtering and pagination."""
        pass

    @abstractmethod
    def get_event_by_id(self, event_id: str) -> Optional[SecurityEvent]:
        """Fetch a specific event by its unique identifier."""
        pass

    @abstractmethod
    def get_stats(self) -> SecurityStats:
        """Calculate live statistics derived exclusively from stored events."""
        pass

    @abstractmethod
    def clear(self) -> None:
        """Clear all stored events (for testing or reset)."""
        pass


class InMemoryEventStore(BaseEventStore):
    """Thread-safe, high-performance in-memory implementation of BaseEventStore."""

    def __init__(self, max_capacity: Optional[int] = None) -> None:
        self._lock = threading.Lock()
        self._max_capacity = max_capacity or get_settings().max_stored_events
        self._events: deque[SecurityEvent] = deque(maxlen=self._max_capacity)
        self._subscribers: List[Callable[[SecurityEvent], Any]] = []

    def register_subscriber(self, subscriber: Callable[[SecurityEvent], Any]) -> None:
        """Register a callback for Person 3 to hook persistence or Discord/Slack notifications.

        Callbacks are invoked synchronously when a new event is emitted.
        """
        with self._lock:
            self._subscribers.append(subscriber)

    def add_event(self, event: SecurityEvent) -> None:
        """Record an event into the store and dispatch to registered subscribers."""
        with self._lock:
            self._events.append(event)
            active_subscribers = list(self._subscribers)

        # Notify subscribers outside the lock to prevent deadlock
        for sub in active_subscribers:
            try:
                sub(event)
            except Exception as e:
                logger.error("Error in event subscriber callback: %s", str(e), exc_info=True)

    def get_events(
        self,
        severity: Optional[SeverityLevel] = None,
        attack_type: Optional[AttackType] = None,
        decoy_triggered: Optional[bool] = None,
        limit: int = 50,
        offset: int = 0,
        reverse_chronological: bool = True,
    ) -> List[SecurityEvent]:
        """Retrieve filtered and paginated events."""
        with self._lock:
            # Snapshot event references
            all_events = list(self._events)

        # Apply ordering (default: newest first)
        if reverse_chronological:
            ordered_events = list(reversed(all_events))
        else:
            ordered_events = all_events

        # Apply filters
        filtered: List[SecurityEvent] = []
        for ev in ordered_events:
            if severity is not None and ev.severity != severity:
                continue
            if attack_type is not None and ev.attack_type != attack_type:
                continue
            if decoy_triggered is not None and ev.decoy_triggered != decoy_triggered:
                continue
            filtered.append(ev)

        # Pagination slice
        safe_limit = max(1, min(limit, 500))
        safe_offset = max(0, offset)
        return filtered[safe_offset : safe_offset + safe_limit]

    def get_event_by_id(self, event_id: str) -> Optional[SecurityEvent]:
        """Retrieve single event by event_id."""
        with self._lock:
            for ev in self._events:
                if ev.event_id == event_id:
                    return ev
        return None

    def get_stats(self) -> SecurityStats:
        """Compute real, verified statistics directly from recorded events."""
        from app.detector import detection_engine

        with self._lock:
            snapshot = list(self._events)

        total_events = len(snapshot)
        severity_counter: Counter[str] = Counter()
        attack_counter: Counter[str] = Counter()
        decoy_count = 0
        unique_ips = set()

        for ev in snapshot:
            severity_counter[ev.severity.value] += 1
            attack_counter[ev.attack_type.value] += 1
            if ev.decoy_triggered:
                decoy_count += 1
            unique_ips.add(ev.source_ip)

        # Standardize severity dictionary keys
        severity_counts = {
            SeverityLevel.LOW.value: severity_counter.get(SeverityLevel.LOW.value, 0),
            SeverityLevel.MEDIUM.value: severity_counter.get(SeverityLevel.MEDIUM.value, 0),
            SeverityLevel.HIGH.value: severity_counter.get(SeverityLevel.HIGH.value, 0),
            SeverityLevel.CRITICAL.value: severity_counter.get(SeverityLevel.CRITICAL.value, 0),
        }

        # Attack type counts
        attack_type_counts = {k: v for k, v in attack_counter.items()}

        aggregate_risk = detection_engine.risk_scorer.get_aggregate_system_risk()
        highest_ip = detection_engine.risk_scorer.get_highest_risk_ip()

        from app.response_engine import response_engine
        active_recs = len(response_engine.get_active_recommendations())

        return SecurityStats(
            total_events=total_events,
            severity_counts=severity_counts,
            attack_type_counts=attack_type_counts,
            decoy_interactions=decoy_count,
            unique_ips=len(unique_ips),
            aggregate_system_risk=aggregate_risk,
            highest_risk_ip=highest_ip,
            active_recommendations_count=active_recs,
        )

    def count(self) -> int:
        """Return total count of in-memory events."""
        with self._lock:
            return len(self._events)

    def clear(self) -> None:
        """Purge all in-memory events and clear subscribers."""
        with self._lock:
            self._events.clear()


# Global singleton event store instance
event_store = InMemoryEventStore()
