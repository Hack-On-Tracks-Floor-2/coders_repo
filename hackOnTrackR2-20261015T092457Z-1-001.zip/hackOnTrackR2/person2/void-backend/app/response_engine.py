"""Defensive response engine generating structured, auditable protection recommendations.

Translates detection findings and aggregate risk levels into operational recommendations:
CONTINUE_MONITORING, INCREASE_MONITORING, APPLY_RATE_LIMIT, REQUEST_TEMPORARY_BLOCK,
and REQUIRE_ANALYST_REVIEW.
"""

from collections import deque
from datetime import datetime, timezone
import logging
import threading
from typing import Dict, List, Optional

from app.config import get_settings
from app.schemas import (
    AttackType,
    DefensiveActionType,
    DefensiveRecommendation,
    SecurityEvent,
    SeverityLevel,
    current_utc_timestamp,
)

logger = logging.getLogger("void.response_engine")


class ResponseEngine:
    """Evaluates risk posture and formulates defensive action recommendations."""

    def __init__(self, max_recommendations: int = 200) -> None:
        self._lock = threading.Lock()
        self._recommendations: deque[DefensiveRecommendation] = deque(maxlen=max_recommendations)
        self._enforced_actions_audit: List[Dict] = []

    def evaluate_event(
        self,
        event: SecurityEvent,
        aggregate_ip_risk: int,
    ) -> DefensiveRecommendation:
        """Formulate a defensive recommendation based on event specifics and cumulative IP risk."""
        settings = get_settings()

        # Decision Matrix based on evaluated threats
        if event.risk_score >= 80 or aggregate_ip_risk >= 80:
            rec = DefensiveRecommendation(
                action_type=DefensiveActionType.REQUEST_TEMPORARY_BLOCK,
                reason=(
                    f"Critical threat threshold reached (Event Score: {event.risk_score}, "
                    f"Aggregate IP Risk: {aggregate_ip_risk}). High-confidence exploitation or multi-vector attack."
                ),
                supporting_event_ids=[event.event_id],
                risk_level=SeverityLevel.CRITICAL,
                human_approval_required=True,
                expires_in_seconds=3600,
                target_ip=event.source_ip,
                remediation_steps=[
                    "Validate source IP ownership and review intercepted payloads in dashboard",
                    "Approve or reject temporary perimeter firewall / WAF block rule",
                    "Review active sessions originating from target IP",
                ],
            )
        elif event.attack_type == AttackType.DECOY_ACCESS:
            rec = DefensiveRecommendation(
                action_type=DefensiveActionType.REQUIRE_ANALYST_REVIEW,
                reason=(
                    f"Deception trap struck at '{event.path}'. Interaction indicates active unauthorized exploration "
                    "or deliberate credential/data hunting."
                ),
                supporting_event_ids=[event.event_id],
                risk_level=SeverityLevel.HIGH,
                human_approval_required=True,
                expires_in_seconds=1800,
                target_ip=event.source_ip,
                remediation_steps=[
                    "Inspect decoy template telemetry logs",
                    "Verify if canary credentials or tokens were saved by requester",
                    "Check for subsequent requests utilizing canary tokens",
                ],
            )
        elif event.attack_type == AttackType.REQUEST_BURST or aggregate_ip_risk >= 50 or event.risk_score >= 50:
            rec = DefensiveRecommendation(
                action_type=DefensiveActionType.APPLY_RATE_LIMIT,
                reason=(
                    f"Elevated request frequency or anomalous payload density detected for {event.source_ip}. "
                    "Automated rate limiting recommended to prevent resource starvation and brute-forcing."
                ),
                supporting_event_ids=[event.event_id],
                risk_level=SeverityLevel.HIGH if event.risk_score >= 50 else SeverityLevel.MEDIUM,
                human_approval_required=False,
                expires_in_seconds=300,
                target_ip=event.source_ip,
                remediation_steps=[
                    "Apply sliding-window token bucket (max 5 requests per minute)",
                    "Log rate-limit breach telemetry for operator review",
                ],
            )
        elif event.attack_type in (AttackType.RECONNAISSANCE, AttackType.PATH_TRAVERSAL) or aggregate_ip_risk >= 30:
            rec = DefensiveRecommendation(
                action_type=DefensiveActionType.INCREASE_MONITORING,
                reason=(
                    f"Reconnaissance or probing indicators detected ({event.attack_type.value}). "
                    "Escalate logging verbosity and profile client interaction patterns."
                ),
                supporting_event_ids=[event.event_id],
                risk_level=SeverityLevel.MEDIUM,
                human_approval_required=False,
                expires_in_seconds=900,
                target_ip=event.source_ip,
                remediation_steps=[
                    "Enable verbose header logging for IP",
                    "Attach session correlation cookie if interactive",
                ],
            )
        else:
            rec = DefensiveRecommendation(
                action_type=DefensiveActionType.CONTINUE_MONITORING,
                reason="Traffic conforms to baseline parameters. Continuous monitoring active.",
                supporting_event_ids=[event.event_id],
                risk_level=SeverityLevel.LOW,
                human_approval_required=False,
                expires_in_seconds=None,
                target_ip=event.source_ip,
                remediation_steps=["Maintain standard telemetry collection"],
            )

        with self._lock:
            self._recommendations.append(rec)

            # Opt-in reversible sandbox enforcement audit
            if settings.auto_enforce_actions and not rec.human_approval_required:
                audit_record = {
                    "applied_at": current_utc_timestamp(),
                    "recommendation_id": rec.recommendation_id,
                    "action": rec.action_type.value,
                    "target_ip": rec.target_ip,
                    "reversible": True,
                    "status": "SIMULATED_ENFORCEMENT_ACTIVE",
                }
                self._enforced_actions_audit.append(audit_record)
                logger.info("Opt-in auto enforcement logged: %s", audit_record)

        return rec

    def get_active_recommendations(self, limit: int = 50) -> List[DefensiveRecommendation]:
        """Return list of generated recommendations, newest first."""
        with self._lock:
            recs = list(self._recommendations)
        recs.reverse()
        return recs[:limit]

    def clear(self) -> None:
        """Clear recorded recommendations and audit log."""
        with self._lock:
            self._recommendations.clear()
            self._enforced_actions_audit.clear()


# Global singleton response engine
response_engine = ResponseEngine()
