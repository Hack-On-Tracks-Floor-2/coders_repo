"""Security interception, client IP resolution, and decoy routing middleware for VOID.

Intercepts incoming traffic, enforces secure path normalization, executes modular
detection rules, short-circuits decoy requests to safe synthetic responses, and records
security telemetry without logging sensitive credentials or tokens.
"""

import logging
import time
import uuid
from typing import Dict
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

from app.config import get_settings
from app.decoys import decoy_registry, normalize_request_path
from app.detector import detection_engine
from app.event_logger import event_store
from app.response_engine import response_engine
from app.schemas import (
    AttackType,
    SecurityAction,
    SecurityEvent,
    SeverityLevel,
    current_utc_timestamp,
)

logger = logging.getLogger("void.security_middleware")

# Headers that must never appear in cleartext security logs
SENSITIVE_HEADERS = {
    "authorization",
    "cookie",
    "set-cookie",
    "x-api-key",
    "proxy-authorization",
    "api-key",
    "session",
    "token",
}


def sanitize_headers(headers: Dict[str, str]) -> Dict[str, str]:
    """Return a sanitized copy of headers with credentials and cookies redacted."""
    sanitized = {}
    for k, v in headers.items():
        k_lower = k.lower()
        if k_lower in SENSITIVE_HEADERS or "token" in k_lower or "secret" in k_lower:
            sanitized[k] = "[REDACTED_CREDENTIAL]"
        else:
            sanitized[k] = v
    return sanitized


def resolve_client_ip(request: Request) -> str:
    """Extract client source IP safely with explicit proxy trust verification."""
    settings = get_settings()
    peer_ip = request.client.host if request.client else "127.0.0.1"

    # Forwarded headers are only trusted when explicitly configured behind trusted proxies
    if settings.trust_proxy_headers and (
        "*" in settings.trusted_proxies or peer_ip in settings.trusted_proxies
    ):
        forwarded = request.headers.get("x-forwarded-for")
        if forwarded:
            # First IP in X-Forwarded-For is the originating client
            client_ip = forwarded.split(",")[0].strip()
            if client_ip:
                return client_ip

        real_ip = request.headers.get("x-real-ip")
        if real_ip:
            return real_ip.strip()

    return peer_ip


class VoidSecurityMiddleware(BaseHTTPMiddleware):
    """Central pipeline middleware for request interception and deception routing."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        start_time = time.time()
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id

        raw_path = request.url.path
        normalized_path = normalize_request_path(raw_path)
        method = request.method
        client_ip = resolve_client_ip(request)
        query_params = dict(request.query_params)
        raw_headers = dict(request.headers)
        clean_headers = sanitize_headers(raw_headers)

        # 1. Evaluate detection engine rules
        findings = detection_engine.evaluate_request(
            method=method,
            path=raw_path,
            query_params=query_params,
            client_ip=client_ip,
            headers=clean_headers,
        )

        # Check whether path targets a configured deception decoy
        decoy = decoy_registry.get_decoy(normalized_path)

        # Calculate score and severity for this request
        event_score, severity, explanation = detection_engine.risk_scorer.calculate_event_score(findings)
        aggregate_ip_risk = detection_engine.risk_scorer.update_ip_risk(client_ip, event_score)

        # 2. Handle Decoy Interception (Short-circuit before real handlers)
        if decoy is not None:
            # Ensure decoy access is recorded as high severity event
            rule_ids = [f.rule_id for f in findings]
            if "DECOY-001" not in rule_ids:
                rule_ids.append("DECOY-001")

            evidence_items = []
            for f in findings:
                evidence_items.extend(f.evidence)
            if not evidence_items:
                evidence_items = [f"Decoy route accessed: {decoy.path}"]

            # Construct unified security event
            sec_event = SecurityEvent(
                path=raw_path,
                method=method,
                attack_type=AttackType.DECOY_ACCESS,
                severity=SeverityLevel.HIGH if severity in (SeverityLevel.LOW, SeverityLevel.MEDIUM) else severity,
                risk_score=max(45, event_score),
                decoy_triggered=True,
                source_ip=client_ip,
                reason=f"Request matched configured decoy route: '{decoy.name}'",
                action=SecurityAction.SYNTHETIC_RESPONSE,
                rule_ids=rule_ids,
                evidence=evidence_items,
                request_id=request_id,
            )

            # Store event and generate defensive recommendation
            event_store.add_event(sec_event)
            response_engine.evaluate_event(sec_event, aggregate_ip_risk)

            logger.warning(
                "DECOY INTERCEPTED: path=%s ip=%s method=%s event_id=%s",
                raw_path,
                client_ip,
                method,
                sec_event.event_id,
            )

            # Generate safe synthetic decoy response
            if decoy.generator:
                synthetic_resp = decoy.generator()
            else:
                synthetic_resp = Response(
                    content="Decoy Resource",
                    status_code=decoy.status_code,
                    media_type=decoy.content_type,
                )

            synthetic_resp.headers["X-Request-ID"] = request_id
            synthetic_resp.headers["X-VOID-Interception"] = "DECOY_TRIGGERED"
            return synthetic_resp

        # 3. Handle Suspicious Indicators on Non-Decoy Routes
        if findings:
            primary_finding = sorted(findings, key=lambda f: f.score_contribution, reverse=True)[0]
            evidence_items = []
            for f in findings:
                evidence_items.extend(f.evidence)

            sec_event = SecurityEvent(
                path=raw_path,
                method=method,
                attack_type=primary_finding.attack_type,
                severity=severity,
                risk_score=event_score,
                decoy_triggered=False,
                source_ip=client_ip,
                reason=explanation,
                action=SecurityAction.LOG_ONLY,
                rule_ids=[f.rule_id for f in findings],
                evidence=evidence_items,
                request_id=request_id,
            )

            event_store.add_event(sec_event)
            response_engine.evaluate_event(sec_event, aggregate_ip_risk)

            logger.info(
                "SECURITY INDICATOR DETECTED: path=%s ip=%s attack_type=%s score=%d",
                raw_path,
                client_ip,
                primary_finding.attack_type.value,
                event_score,
            )

        # 4. Legitimate Traffic - Proceed to intended route handler
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response
