"""VOID — AI-Powered Cyber Defense Backend.

Core Pipeline and Logic Engine.
"""

__version__ = "1.0.0"
