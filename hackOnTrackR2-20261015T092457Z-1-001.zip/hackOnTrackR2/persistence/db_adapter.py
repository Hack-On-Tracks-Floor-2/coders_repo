"""VOID // SENTINEL — Production Persistence Adapter.

Thread-safe, WAL-enabled event storage engine supporting SQLite and optional PostgreSQL.
Implements idempotent persistence, filtering, analytics aggregation, and auto-DDL bootstrap.
Guaranteed to never raise exceptions into the caller's request path.
"""

from datetime import datetime, timedelta, timezone
import json
import logging
import os
from pathlib import Path
import sqlite3
import threading
from typing import Any, Dict, List, Optional, Union

# Handle schemas import whether running standalone or as a package
try:
    from app.schemas import AttackType, SecurityAction, SecurityEvent, SeverityLevel
except ImportError:
    from schemas import AttackType, SecurityAction, SecurityEvent, SeverityLevel

logger = logging.getLogger("void.persistence")


class EventPersistence:
    """Thread-safe persistence layer for VOID Security Events."""

    def __init__(
        self,
        db_path: Optional[str] = None,
        schema_path: Optional[str] = None,
        database_url: Optional[str] = None,
    ) -> None:
        """Initialize database persistence.

        Args:
            db_path: Path to SQLite database file. Defaults to env VOID_DB_PATH
                     or 'void_security_events.db'.
            schema_path: Path to database_schema.sql file.
            database_url: Optional database URL (e.g. postgresql://...). Defaults
                          to env DATABASE_URL.
        """
        self.database_url = database_url or os.getenv("DATABASE_URL")
        self.is_postgres = bool(
            self.database_url and self.database_url.startswith(("postgres://", "postgresql://"))
        )
        self.db_path = db_path or os.getenv("VOID_DB_PATH", "void_security_events.db")
        self.schema_path = schema_path
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._pg_conn = None

        if self.is_postgres:
            self._init_postgres()
        else:
            self._init_sqlite()

    def _get_sqlite_connection(self) -> sqlite3.Connection:
        """Get or initialize thread-safe SQLite connection with WAL mode."""
        if self._conn is None:
            self._conn = sqlite3.connect(
                self.db_path,
                check_same_thread=False,
                timeout=10.0,
            )
            self._conn.row_factory = sqlite3.Row
            # WAL mode for high concurrency and resilience
            self._conn.execute("PRAGMA journal_mode = WAL;")
            self._conn.execute("PRAGMA synchronous = NORMAL;")
            self._conn.execute("PRAGMA busy_timeout = 5000;")
            self._conn.execute("PRAGMA foreign_keys = ON;")
        return self._conn

    def _init_postgres(self) -> None:
        """Initialize PostgreSQL connection and bootstrap schema."""
        try:
            import psycopg2  # type: ignore
            from psycopg2.extras import RealDictCursor  # type: ignore

            self._pg_conn = psycopg2.connect(self.database_url, cursor_factory=RealDictCursor)
            self._pg_conn.autocommit = True
            logger.info("Connected to PostgreSQL persistence: %s", self.database_url.split("@")[-1])
            self._bootstrap_schema()
        except ImportError:
            logger.warning("psycopg2 is not installed. Falling back to SQLite default.")
            self.is_postgres = False
            self._init_sqlite()
        except Exception as e:
            logger.error("Failed to connect to PostgreSQL (%s). Falling back to SQLite.", e)
            self.is_postgres = False
            self._init_sqlite()

    def _init_sqlite(self) -> None:
        """Initialize SQLite connection and bootstrap tables & indexes."""
        with self._lock:
            try:
                conn = self._get_sqlite_connection()
                self._bootstrap_schema()
                logger.info("Initialized SQLite persistence with WAL mode at '%s'", self.db_path)
            except Exception as e:
                logger.error("Failed initializing SQLite database: %s", e, exc_info=True)

    def _find_schema_file(self) -> Optional[Path]:
        """Locate database_schema.sql in standard project locations."""
        candidates = []
        if self.schema_path:
            candidates.append(Path(self.schema_path))
        candidates.extend([
            Path("database_schema.sql"),
            Path(__file__).parent / "database_schema.sql",
            Path(__file__).parent.parent / "database_schema.sql",
        ])
        for path in candidates:
            if path.exists() and path.is_file():
                return path.resolve()
        return None

    def _bootstrap_schema(self) -> None:
        """Auto-run database_schema.sql if present, otherwise use built-in DDL."""
        schema_file = self._find_schema_file()
        if self.is_postgres and self._pg_conn:
            # Postgres fallback DDL
            with self._pg_conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS security_events (
                        event_id VARCHAR(36) PRIMARY KEY,
                        timestamp TIMESTAMPTZ NOT NULL,
                        path TEXT NOT NULL,
                        method VARCHAR(10) NOT NULL,
                        attack_type VARCHAR(32) NOT NULL,
                        severity VARCHAR(16) NOT NULL,
                        risk_score SMALLINT NOT NULL CHECK (risk_score >= 0 AND risk_score <= 100),
                        decoy_triggered BOOLEAN NOT NULL DEFAULT FALSE,
                        source_ip VARCHAR(64) NOT NULL,
                        reason TEXT NOT NULL,
                        action VARCHAR(32) NOT NULL,
                        rule_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
                        evidence JSONB NOT NULL DEFAULT '[]'::jsonb,
                        request_id VARCHAR(64) NOT NULL,
                        created_at TIMESTAMPTZ DEFAULT NOW()
                    );
                    CREATE TABLE IF NOT EXISTS blacklisted_ips (
                        ip VARCHAR(64) PRIMARY KEY,
                        reason TEXT DEFAULT '',
                        created_at TIMESTAMPTZ DEFAULT NOW()
                    );
                """)
            return

        with self._lock:
            conn = self._get_sqlite_connection()
            executed_from_file = False
            if schema_file:
                try:
                    sql_content = schema_file.read_text(encoding="utf-8")
                    # Split or execute SQLite DDL portion
                    # Filter out postgres multi-line comment if present
                    lines = []
                    in_pg_comment = False
                    for line in sql_content.splitlines():
                        if "/*" in line:
                            in_pg_comment = True
                        if in_pg_comment:
                            if "*/" in line:
                                in_pg_comment = False
                            continue
                        lines.append(line)
                    sqlite_ddl = "\n".join(lines)
                    conn.executescript(sqlite_ddl)
                    conn.commit()
                    executed_from_file = True
                    logger.info("Successfully executed DDL from '%s'", schema_file)
                except Exception as e:
                    logger.warning("Could not execute DDL from file '%s': %s. Using embedded DDL.", schema_file, e)

            if not executed_from_file:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS security_events (
                        event_id VARCHAR(36) PRIMARY KEY,
                        timestamp TEXT NOT NULL,
                        path TEXT NOT NULL,
                        method VARCHAR(10) NOT NULL,
                        attack_type VARCHAR(32) NOT NULL,
                        severity VARCHAR(16) NOT NULL,
                        risk_score INTEGER NOT NULL CHECK (risk_score >= 0 AND risk_score <= 100),
                        decoy_triggered BOOLEAN NOT NULL DEFAULT 0,
                        source_ip VARCHAR(64) NOT NULL,
                        reason TEXT NOT NULL,
                        action VARCHAR(32) NOT NULL,
                        rule_ids TEXT NOT NULL DEFAULT '[]',
                        evidence TEXT NOT NULL DEFAULT '[]',
                        request_id VARCHAR(64) NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """)
                conn.execute("CREATE INDEX IF NOT EXISTS idx_events_timestamp ON security_events(timestamp DESC);")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_events_severity ON security_events(severity);")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_events_attack_type ON security_events(attack_type);")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_events_decoy ON security_events(decoy_triggered);")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_events_ip ON security_events(source_ip);")

            # Always ensure blacklisted_ips table exists for dashboard support
            conn.execute("""
                CREATE TABLE IF NOT EXISTS blacklisted_ips (
                    ip VARCHAR(64) PRIMARY KEY,
                    reason TEXT DEFAULT '',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            conn.commit()

    def save_event(self, event: Union[SecurityEvent, Dict[str, Any]]) -> bool:
        """Persist a security event into storage.

        Uses INSERT OR IGNORE for idempotency.
        Guaranteed NEVER to raise an exception into Person 1's request path.

        Args:
            event: SecurityEvent instance or dictionary matching event schema.

        Returns:
            True if save succeeded or was ignored as duplicate; False on error.
        """
        try:
            # Normalize event data
            if isinstance(event, dict):
                event_id = str(event.get("event_id"))
                timestamp = str(event.get("timestamp"))
                path = str(event.get("path"))
                method = str(event.get("method"))
                attack_type = event.get("attack_type")
                if hasattr(attack_type, "value"):
                    attack_type = attack_type.value
                severity = event.get("severity")
                if hasattr(severity, "value"):
                    severity = severity.value
                risk_score = int(event.get("risk_score", 0))
                decoy_triggered = bool(event.get("decoy_triggered", False))
                source_ip = str(event.get("source_ip"))
                reason = str(event.get("reason", ""))
                action = event.get("action")
                if hasattr(action, "value"):
                    action = action.value
                rule_ids = event.get("rule_ids", [])
                evidence = event.get("evidence", [])
                request_id = str(event.get("request_id", ""))
            else:
                event_id = str(event.event_id)
                timestamp = str(event.timestamp)
                path = str(event.path)
                method = str(event.method)
                attack_type = event.attack_type.value if hasattr(event.attack_type, "value") else str(event.attack_type)
                severity = event.severity.value if hasattr(event.severity, "value") else str(event.severity)
                risk_score = int(event.risk_score)
                decoy_triggered = bool(event.decoy_triggered)
                source_ip = str(event.source_ip)
                reason = str(event.reason)
                action = event.action.value if hasattr(event.action, "value") else str(event.action)
                rule_ids = event.rule_ids
                evidence = event.evidence
                request_id = str(event.request_id)

            rule_ids_json = json.dumps(rule_ids) if not isinstance(rule_ids, str) else rule_ids
            evidence_json = json.dumps(evidence) if not isinstance(evidence, str) else evidence

            if self.is_postgres and self._pg_conn:
                with self._pg_conn.cursor() as cur:
                    cur.execute(
                        """
                        INSERT INTO security_events (
                            event_id, timestamp, path, method, attack_type,
                            severity, risk_score, decoy_triggered, source_ip,
                            reason, action, rule_ids, evidence, request_id
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (event_id) DO NOTHING;
                        """,
                        (
                            event_id, timestamp, path, method, attack_type,
                            severity, risk_score, decoy_triggered, source_ip,
                            reason, action, rule_ids_json, evidence_json, request_id,
                        ),
                    )
                return True

            with self._lock:
                conn = self._get_sqlite_connection()
                conn.execute(
                    """
                    INSERT OR IGNORE INTO security_events (
                        event_id, timestamp, path, method, attack_type,
                        severity, risk_score, decoy_triggered, source_ip,
                        reason, action, rule_ids, evidence, request_id
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        event_id,
                        timestamp,
                        path,
                        method,
                        str(attack_type),
                        str(severity),
                        risk_score,
                        1 if decoy_triggered else 0,
                        source_ip,
                        reason,
                        str(action),
                        rule_ids_json,
                        evidence_json,
                        request_id,
                    ),
                )
                conn.commit()
            return True

        except Exception as exc:
            logger.error("Failed to persist security event (safe suppression): %s", exc, exc_info=True)
            return False

    def query_events(
        self,
        limit: int = 50,
        severity: Optional[str] = None,
        decoy_only: Optional[bool] = None,
        source_ip: Optional[str] = None,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """Query stored events with optional filtering and pagination.

        Args:
            limit: Maximum records to return.
            severity: Filter by severity ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL').
            decoy_only: If True, only return events where decoy_triggered = 1.
            source_ip: Filter by specific client IP.
            offset: Record offset for pagination.

        Returns:
            List of parsed event dictionaries with JSON fields unpacked.
        """
        with self._lock:
            conn = self._get_sqlite_connection()
            query = "SELECT * FROM security_events WHERE 1=1"
            params: List[Any] = []

            if severity:
                query += " AND severity = ?"
                params.append(severity.upper())
            if decoy_only is not None:
                query += " AND decoy_triggered = ?"
                params.append(1 if decoy_only else 0)
            if source_ip:
                query += " AND source_ip = ?"
                params.append(source_ip)

            query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            params.extend([max(1, limit), max(0, offset)])

            cursor = conn.execute(query, tuple(params))
            rows = cursor.fetchall()

            results: List[Dict[str, Any]] = []
            for row in rows:
                item = dict(row)
                item["decoy_triggered"] = bool(item.get("decoy_triggered", 0))
                # Safely parse JSON serialized fields
                for json_field in ("rule_ids", "evidence"):
                    val = item.get(json_field)
                    if isinstance(val, str):
                        try:
                            item[json_field] = json.loads(val)
                        except Exception:
                            item[json_field] = []
                    elif val is None:
                        item[json_field] = []
                results.append(item)
            return results

    def get_event_by_id(self, event_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a single event by event_id."""
        with self._lock:
            conn = self._get_sqlite_connection()
            cursor = conn.execute(
                "SELECT * FROM security_events WHERE event_id = ? LIMIT 1",
                (event_id,),
            )
            row = cursor.fetchone()
            if not row:
                return None
            item = dict(row)
            item["decoy_triggered"] = bool(item.get("decoy_triggered", 0))
            for json_field in ("rule_ids", "evidence"):
                val = item.get(json_field)
                if isinstance(val, str):
                    try:
                        item[json_field] = json.loads(val)
                    except Exception:
                        item[json_field] = []
            return item

    def get_event_count(self) -> int:
        """Return total count of recorded events."""
        with self._lock:
            conn = self._get_sqlite_connection()
            cursor = conn.execute("SELECT COUNT(*) FROM security_events")
            res = cursor.fetchone()
            return int(res[0]) if res else 0

    def get_stats(self) -> Dict[str, Any]:
        """Calculate comprehensive security statistics from the persistent database."""
        with self._lock:
            conn = self._get_sqlite_connection()

            # Total count
            total = self.get_event_count()

            # Breakdown by severity
            sev_cursor = conn.execute(
                "SELECT severity, COUNT(*) as cnt FROM security_events GROUP BY severity"
            )
            by_severity = {
                "CRITICAL": 0,
                "HIGH": 0,
                "MEDIUM": 0,
                "LOW": 0,
            }
            for row in sev_cursor.fetchall():
                by_severity[row["severity"]] = int(row["cnt"])

            # Breakdown by attack_type
            atk_cursor = conn.execute(
                "SELECT attack_type, COUNT(*) as cnt FROM security_events GROUP BY attack_type ORDER BY cnt DESC"
            )
            by_attack_type = {row["attack_type"]: int(row["cnt"]) for row in atk_cursor.fetchall()}

            # Decoy interactions count
            decoy_cursor = conn.execute(
                "SELECT COUNT(*) FROM security_events WHERE decoy_triggered = 1"
            )
            decoy_hits = int(decoy_cursor.fetchone()[0])

            # Top source IPs by activity and threat score
            ip_cursor = conn.execute(
                """
                SELECT source_ip, COUNT(*) as cnt, AVG(risk_score) as avg_score, MAX(risk_score) as max_score
                FROM security_events
                GROUP BY source_ip
                ORDER BY cnt DESC, max_score DESC
                LIMIT 10
                """
            )
            top_ips = [
                {
                    "ip": row["source_ip"],
                    "count": int(row["cnt"]),
                    "avg_risk": round(float(row["avg_score"] or 0), 1),
                    "max_risk": int(row["max_score"] or 0),
                }
                for row in ip_cursor.fetchall()
            ]

            # Unique IP count
            uniq_cursor = conn.execute("SELECT COUNT(DISTINCT source_ip) FROM security_events")
            unique_ips = int(uniq_cursor.fetchone()[0])

            # Blocklist count
            block_cursor = conn.execute("SELECT COUNT(*) FROM blacklisted_ips")
            blocklist_size = int(block_cursor.fetchone()[0])

            # Aggregate system risk score (average of top risk scores or peak)
            peak_cursor = conn.execute("SELECT MAX(risk_score) FROM security_events")
            peak_risk = peak_cursor.fetchone()[0] or 0

            return {
                "total": total,
                "total_events": total,
                "by_severity": by_severity,
                "severity_counts": by_severity,
                "by_attack_type": by_attack_type,
                "attack_type_counts": by_attack_type,
                "decoy_hits": decoy_hits,
                "decoy_interactions": decoy_hits,
                "top_ips": top_ips,
                "unique_ips": unique_ips,
                "blocklist_size": blocklist_size,
                "aggregate_system_risk": int(peak_risk),
            }

    def purge_older_than(self, days: int) -> int:
        """Purge events older than specified number of days.

        Args:
            days: Retention threshold in days.

        Returns:
            Count of rows deleted.
        """
        if days < 0:
            return 0
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        cutoff_iso = cutoff.isoformat()

        with self._lock:
            conn = self._get_sqlite_connection()
            cursor = conn.execute(
                "DELETE FROM security_events WHERE timestamp < ?",
                (cutoff_iso,),
            )
            deleted_count = cursor.rowcount
            conn.commit()
            logger.info("Purged %d security events older than %d days (cutoff: %s)", deleted_count, days, cutoff_iso)
            return deleted_count

    # Blacklist management methods
    def add_blacklisted_ip(self, ip: str, reason: str = "") -> bool:
        """Add an IP to persistent blacklist."""
        try:
            with self._lock:
                conn = self._get_sqlite_connection()
                conn.execute(
                    "INSERT OR REPLACE INTO blacklisted_ips (ip, reason) VALUES (?, ?)",
                    (ip.strip(), reason.strip()),
                )
                conn.commit()
                return True
        except Exception as e:
            logger.error("Failed to add blacklisted IP %s: %s", ip, e)
            return False

    def remove_blacklisted_ip(self, ip: str) -> bool:
        """Remove an IP from persistent blacklist."""
        try:
            with self._lock:
                conn = self._get_sqlite_connection()
                cursor = conn.execute("DELETE FROM blacklisted_ips WHERE ip = ?", (ip.strip(),))
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            logger.error("Failed to remove blacklisted IP %s: %s", ip, e)
            return False

    def is_ip_blacklisted(self, ip: str) -> bool:
        """Check if an IP is in the blacklist."""
        with self._lock:
            conn = self._get_sqlite_connection()
            cursor = conn.execute("SELECT 1 FROM blacklisted_ips WHERE ip = ? LIMIT 1", (ip.strip(),))
            return cursor.fetchone() is not None

    def get_blacklisted_ips(self) -> List[Dict[str, Any]]:
        """Return all blacklisted IPs."""
        with self._lock:
            conn = self._get_sqlite_connection()
            cursor = conn.execute("SELECT ip, reason, created_at FROM blacklisted_ips ORDER BY created_at DESC")
            return [dict(row) for row in cursor.fetchall()]

    def close(self) -> None:
        """Close database connection."""
        with self._lock:
            if self._conn:
                try:
                    self._conn.close()
                except Exception:
                    pass
                self._conn = None
            if self._pg_conn:
                try:
                    self._pg_conn.close()
                except Exception:
                    pass
                self._pg_conn = None


# Backward-compatibility alias
SqliteEventPersistence = EventPersistence
