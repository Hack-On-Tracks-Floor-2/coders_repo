"""Persistence module for VOID // SENTINEL."""
from .db_adapter import EventPersistence, SqliteEventPersistence

__all__ = ["EventPersistence", "SqliteEventPersistence"]
